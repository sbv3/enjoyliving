-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.biorythm
CREATE TABLE IF NOT EXISTS `biorythm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `result` decimal(10,0) NOT NULL DEFAULT '0',
  `img` text COLLATE latin1_german2_ci NOT NULL,
  `code` text COLLATE latin1_german2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.biorythm: 84 rows
/*!40000 ALTER TABLE `biorythm` DISABLE KEYS */;
INSERT INTO `biorythm` (`id`, `result`, `img`, `code`) VALUES
	(1, 88, '01.gif', 'physical'),
	(2, 97, '02.gif', 'physical'),
	(3, 99, '03.gif', 'physical'),
	(4, 94, '04.gif', 'physical'),
	(5, 81, '05.gif', 'physical'),
	(6, 63, '06.gif', 'physical'),
	(7, 39, '07.gif', 'physical'),
	(8, 13, '08.gif', 'physical'),
	(9, -14, '09.gif', 'physical'),
	(10, -40, '10.gif', 'physical'),
	(11, -64, '11.gif', 'physical'),
	(12, -82, '12.gif', 'physical'),
	(13, -95, '13.gif', 'physical'),
	(14, -100, '14.gif', 'physical'),
	(15, -98, '15.gif', 'physical'),
	(16, -89, '16.gif', 'physical'),
	(17, -74, '17.gif', 'physical'),
	(18, -52, '18.gif', 'physical'),
	(19, -27, '19.gif', 'physical'),
	(20, -1, '20.gif', 'physical'),
	(21, 26, '21.gif', 'physical'),
	(22, 51, '22.gif', 'physical'),
	(23, 73, '23.gif', 'physical'),
	(24, 98, '01.gif', 'emotional'),
	(25, 99, '02.gif', 'emotional'),
	(26, 96, '03.gif', 'emotional'),
	(27, 88, '04.gif', 'emotional'),
	(28, 75, '05.gif', 'emotional'),
	(29, 59, '06.gif', 'emotional'),
	(30, 40, '07.gif', 'emotional'),
	(31, 18, '08.gif', 'emotional'),
	(32, -4, '09.gif', 'emotional'),
	(33, -26, '10.gif', 'emotional'),
	(34, -47, '11.gif', 'emotional'),
	(35, -66, '12.gif', 'emotional'),
	(36, -81, '13.gif', 'emotional'),
	(37, -92, '14.gif', 'emotional'),
	(38, -99, '15.gif', 'emotional'),
	(39, -100, '16.gif', 'emotional'),
	(40, -97, '17.gif', 'emotional'),
	(41, -89, '18.gif', 'emotional'),
	(42, -76, '19.gif', 'emotional'),
	(43, -60, '20.gif', 'emotional'),
	(44, -41, '21.gif', 'emotional'),
	(45, -19, '22.gif', 'emotional'),
	(46, 3, '23.gif', 'emotional'),
	(47, 25, '24.gif', 'emotional'),
	(48, 46, '25.gif', 'emotional'),
	(49, 65, '26.gif', 'emotional'),
	(50, 80, '27.gif', 'emotional'),
	(51, 91, '28.gif', 'emotional'),
	(52, 94, '01.gif', 'mental'),
	(53, 86, '02.gif', 'mental'),
	(54, 75, '03.gif', 'mental'),
	(55, 61, '04.gif', 'mental'),
	(56, 45, '05.gif', 'mental'),
	(57, 28, '06.gif', 'mental'),
	(58, 9, '07.gif', 'mental'),
	(59, -10, '08.gif', 'mental'),
	(60, -29, '09.gif', 'mental'),
	(61, -46, '10.gif', 'mental'),
	(62, -62, '11.gif', 'mental'),
	(63, -76, '12.gif', 'mental'),
	(64, -87, '13.gif', 'mental'),
	(65, -95, '14.gif', 'mental'),
	(66, -99, '15.gif', 'mental'),
	(67, -100, '16.gif', 'mental'),
	(68, -98, '17.gif', 'mental'),
	(69, -91, '18.gif', 'mental'),
	(70, -82, '19.gif', 'mental'),
	(71, -70, '20.gif', 'mental'),
	(72, -55, '21.gif', 'mental'),
	(73, -38, '22.gif', 'mental'),
	(74, -19, '23.gif', 'mental'),
	(75, -1, '24.gif', 'mental'),
	(76, 18, '25.gif', 'mental'),
	(77, 37, '26.gif', 'mental'),
	(79, 54, '27.gif', 'mental'),
	(80, 69, '28.gif', 'mental'),
	(81, 81, '29.gif', 'mental'),
	(82, 90, '30.gif', 'mental'),
	(83, 97, '31.gif', 'mental'),
	(84, 99, '32.gif', 'mental'),
	(85, 98, '33.gif', 'mental');
/*!40000 ALTER TABLE `biorythm` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
