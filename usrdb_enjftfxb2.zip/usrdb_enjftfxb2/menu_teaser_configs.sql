-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.menu_teaser_configs
CREATE TABLE IF NOT EXISTS `menu_teaser_configs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `description` char(50) COLLATE utf8_unicode_ci NOT NULL,
  `explanation` text COLLATE utf8_unicode_ci NOT NULL,
  `clippingbox_breite` int(11) NOT NULL DEFAULT '0',
  `clippingbox_hoehe` int(11) NOT NULL DEFAULT '0',
  `parent_needed` int(11) NOT NULL DEFAULT '0',
  `einleitung_needed` int(11) NOT NULL DEFAULT '0',
  `img_needed` int(11) NOT NULL DEFAULT '0',
  `lesen_flag_needed` int(11) NOT NULL DEFAULT '0',
  `containerwidth` int(11) NOT NULL DEFAULT '0',
  `teasercopycols` int(11) NOT NULL DEFAULT '0',
  `col_nr` int(11) NOT NULL DEFAULT '0',
  `truncate_length` int(11) NOT NULL DEFAULT '0',
  `display_include_pfad` char(50) COLLATE utf8_unicode_ci DEFAULT '0',
  `admin_display_include_pfad` char(50) COLLATE utf8_unicode_ci DEFAULT '0',
  `auto_manual` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rubrik_subseiten` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.menu_teaser_configs: ~15 rows (ungefähr)
/*!40000 ALTER TABLE `menu_teaser_configs` DISABLE KEYS */;
INSERT INTO `menu_teaser_configs` (`id`, `description`, `explanation`, `clippingbox_breite`, `clippingbox_hoehe`, `parent_needed`, `einleitung_needed`, `img_needed`, `lesen_flag_needed`, `containerwidth`, `teasercopycols`, `col_nr`, `truncate_length`, `display_include_pfad`, `admin_display_include_pfad`, `auto_manual`, `rubrik_subseiten`) VALUES
	(1, 'single image', 'Zeigt nur manuell ausgewählten Einträge. Ein Bild pro Zeile.', 150, 85, 1, 1, 1, 1, 605, 67, 1, 999, '', '', 'manual', ''),
	(2, 'dual image', 'Zeigt nur manuell ausgewählten Einträge. Zwei Bilder pro Zeile.', 132, 80, 1, 1, 1, 1, 298, 40, 2, 999, '', '', 'manual', NULL),
	(3, 'single no image', 'Zeigt nur manuell ausgewählten Einträge. Ohne Bild, ohne Kategorieüberschrift.', 150, 85, 0, 1, 0, 1, 620, 67, 1, 999, '', '', 'manual', NULL),
	(4, 'single image auto (Siblings)', 'Zeigt alle aktiven Einträge der nächsten Menüebene. Ein Bild pro Zeile.', 150, 85, 1, 1, 1, 1, 605, 67, 1, 100, '/site_12_1/menu_teaser_auto.php', '/site_12_1/admin/admin_menu_teaser_auto.php', 'auto', 'sibling'),
	(5, 'dual image auto (Siblings)', 'Zeigt alle aktiven Einträge der nächsten Menüebene. Zwei Bilder pro Zeile.', 132, 80, 1, 1, 1, 1, 298, 40, 2, 100, '/site_12_1/menu_teaser_auto.php', '/site_12_1/admin/admin_menu_teaser_auto.php', 'auto', 'sibling'),
	(7, 'single image auto (all siblings)', 'Zeigt alle aktiven Artikel (nicht Menüs) aller tieferen Menüebenen. Ein Bild pro Zeile.', 150, 85, 1, 1, 1, 1, 605, 67, 1, 100, '/site_12_1/menu_teaser_auto.php', '/site_12_1/admin/admin_menu_teaser_auto.php', 'auto', 'all_siblings'),
	(8, 'dual image auto (all siblings)', 'Zeigt alle aktiven Artikel (nicht Menüs) aller tieferen Menüebenen. Zwei Bilder pro Zeile.', 132, 80, 1, 1, 1, 1, 298, 40, 2, 100, '/site_12_1/menu_teaser_auto.php', '/site_12_1/admin/admin_menu_teaser_auto.php', 'auto', 'all_siblings'),
	(9, 'Seitenc. single image', 'Zeigt nur manuell ausgewählten Einträge. Ein Bild pro Zeile. Ohne "mehr lesen" flag.', 70, 45, 1, 1, 1, 0, 290, 67, 1, 999, '', '', 'manual', ''),
	(11, 'Seitenc. no image', 'Zeigt nur manuell ausgewählten Einträge. Ohne Bild, ohne Kategorieüberschrift, ohne "mehr lesen" flag.', 70, 45, 0, 1, 0, 0, 290, 67, 1, 999, '', '', 'manual', NULL),
	(13, 'Seitenc. single image auto (Siblings)', 'Zeigt alle aktiven Einträge der nächsten Menüebene. Ein Bild pro Zeile. Ohne Kategorieüberschrift. Ohne "mehr lesen" flag.', 70, 45, 0, 1, 1, 0, 290, 67, 1, 50, '/site_12_1/menu_teaser_auto.php', '/site_12_1/admin/admin_menu_teaser_auto.php', 'auto', 'sibling'),
	(14, 'Seitenc. single image auto (all siblings)', 'Zeigt alle aktiven Artikel (nicht Menüs) aller tieferen Menüebenen. Ein Bild pro Zeile. Ohne Kategorieüberschrift. Ohne "mehr lesen" flag.', 70, 45, 0, 1, 1, 0, 290, 67, 1, 50, '/site_12_1/menu_teaser_auto.php', '/site_12_1/admin/admin_menu_teaser_auto.php', 'auto', 'all_siblings'),
	(16, 'Seitenc. no image auto (Sibling)', 'Zeigt alle aktiven Einträge der nächsten Menüebene. Ohne Bild, ohne Kategorieüberschrift, ohne "mehr lesen" flag.', 70, 45, 0, 1, 0, 0, 290, 67, 1, 50, '/site_12_1/menu_teaser_auto.php', '/site_12_1/admin/admin_menu_teaser_auto.php', 'auto', 'sibling'),
	(17, 'single auto no image (Siblings)', 'Zeigt alle aktiven Einträge der nächsten Menüebene. Ohne Bild.', 150, 85, 1, 1, 0, 1, 605, 67, 1, 100, '/site_12_1/menu_teaser_auto.php', '/site_12_1/admin/admin_menu_teaser_auto.php', 'auto', 'sibling'),
	(18, 'dual no image, no intro', 'Zeigt nur manuell ausgewählten Einträge. Ohne Bild, ohne Kategorieüberschrift. Zwei pro Zeile.', 132, 80, 0, 0, 0, 0, 298, 40, 2, 999, '', '', 'manual', NULL),
	(19, 'single no image, to intro', 'Zeigt nur manuell ausgewählten Einträge. Ohne Bild, ohne Kategorieüberschrift. Einer pro Zeile.', 150, 85, 0, 0, 0, 0, 605, 67, 1, 999, '', '', 'manual', NULL);
/*!40000 ALTER TABLE `menu_teaser_configs` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
