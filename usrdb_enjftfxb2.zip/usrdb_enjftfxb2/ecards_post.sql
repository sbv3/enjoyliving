-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.ecards_post
CREATE TABLE IF NOT EXISTS `ecards_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_von` text COLLATE latin1_german2_ci NOT NULL,
  `email_von` text COLLATE latin1_german2_ci NOT NULL,
  `name_an` text COLLATE latin1_german2_ci NOT NULL,
  `email_an` text COLLATE latin1_german2_ci NOT NULL,
  `karte` text COLLATE latin1_german2_ci NOT NULL,
  `text` text COLLATE latin1_german2_ci NOT NULL,
  `code` text COLLATE latin1_german2_ci NOT NULL,
  `datum` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=637 DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.ecards_post: 46 rows
/*!40000 ALTER TABLE `ecards_post` DISABLE KEYS */;
INSERT INTO `ecards_post` (`id`, `name_von`, `email_von`, `name_an`, `email_an`, `karte`, `text`, `code`, `datum`) VALUES
	(591, 'asdasd', 'asdasd@.', 'sdf sdf', 'sdf@sd.', '', '±×ì±×', '6492', '2011-06-18 20:26:36'),
	(592, 'asdasd', 'asdasd@.', 'sdf sdf', 'sdf@sd.', '', '±×ì±×', '4281', '2011-06-18 20:29:58'),
	(593, 'asdasd', 'asdasd@.', 'sdf sdf', 'sdf@sd.', '', 'sdfs sdf', '6549', '2011-06-18 20:44:12'),
	(594, 'Mir', 'bela@virag-keg.com', 'Dich', 'claudia@enjoyliving.at', '', 'An Dich, von mir ;-))', '9958', '2011-06-18 21:29:39'),
	(595, 'mausi', 'claudia@enjoyliving.at', 'bärli', 'bela@virag-keg.com', '', 'eeeee', '2226', '2011-11-06 13:25:44'),
	(596, 'sdfsdf', 'sdfsdf@.c', 'ddd', 'dddd@.', '', '', '4310', '2011-11-06 15:50:30'),
	(597, 'Claudi', 'claudia@enjoyliving.at', 'Bela', 'bela@virag-keg.com', '', 'Hallo mein Schatz!<br />\r\n<br />\r\nHab Dich ganz fest lieb!<br />\r\n<br />\r\nkuss<br />\r\nmausi', '3266', '2011-11-06 15:56:23'),
	(598, 'Carmen', 'angelus3@gmx.at', 'Christian', 'CNeumann@gmx.at', '', 'Lieber Christian,<br />\r\n<br />\r\njetzt aber schnell, bevor ich wieder zur Arbeit muss. Eigentlich wollte ich dir ein etwas längere Nachricht schreiben, aber wie immer ist montags meine Pause viel zu kurz. <br />\r\n<br />\r\nWie geht es dir? Ich hab dich schon soooo lange nicht mehr gehört. Du fehlst mir sehr und ich hoffe, dass wir bald wieder einmal Zeit für uns zwei finden. <br />\r\n<br />\r\nIn diesem Sinne schicke ich dir einen süßen Kuss und drück dich ganz fest an mich (wenigstens in Gedanken!).<br />\r\n<br />\r\nhdl<br />\r\ndeine Maus ', '9838', '2011-12-12 15:38:02'),
	(599, 'sigi', 'simiflo@gmx.at', 'sigrid', 'office@funsports.eu', '', '', '5033', '2011-12-28 09:51:38'),
	(600, 'Ingrid Schinnerl', 'ingridschinnerl@gmx.at', 'Simone Berger', 'simoneberger@gmx.at', '', '', '3729', '2012-01-20 11:14:53'),
	(601, 'burgal.s', 'burgal.s@aon.at', 'semisch', 'semisch@ewbau.at', '', '', '8749', '2012-01-23 18:07:14'),
	(602, 'Aischa', 'diedreias@yahoo.de', 'Aleyna', 'frankenvanessa@yahoo.de', '', 'Liebe Aleyna<br />\r\nWollte dir nur eine kleine Freude bereiten bin immer in Gedanken bei dir mein schatz .Kopf hoch das wirst du alles schaffen Maschaallah bin stolz das ich so eine süsse sr habe.Pass auf dich und deine Mädels auf<br />\r\n<br />\r\n<br />\r\nWaleikum Salam deine Aischa(Mama Tauhid)', '2177', '2012-01-29 18:06:26'),
	(603, 'Fresie', 'fresie01@googlemail.com', 'Antje', 'a.vagt@rosengart-vagt.de', '', '', '3560', '2012-01-30 22:55:34'),
	(604, 'Mama', 'Johanna.schiller@basb.gv.at', 'Tina', 'tina.schiller@justiz.gv.at', '', '', '1947', '2012-02-02 06:55:26'),
	(605, 'Hanni', 'Johanna.schiller@basb.gv.at', 'Hanni', 'hanni_orischnig@hotmail.com', '', '', '9469', '2012-02-02 06:57:01'),
	(606, 'Augenschmaus ;-)', 'raphaela.koenig@gmail.com', 'Dragi Moj', 'slavko.dragojevic@gmail.com', '', '', '6666', '2012-02-14 12:12:10'),
	(607, 'Augenschmaus ;-)', 'raphaela.koenig@gmail.com', 'Dragi Moj', 'slavko.dragojevic@gmail.com', '', '', '3699', '2012-02-14 12:12:31'),
	(608, 'Edith', 'edith.strini1@gmail.com', 'Kurt', 'kurt.raber@hotmail.com', '', '', '1796', '2012-02-29 10:58:50'),
	(609, 'Edith', 'edith.strini1@gmail.com', 'Kurt', 'kurt.raber@hotmail.com', '', '', '5952', '2012-02-29 11:07:19'),
	(610, 'Peter', 'peter_oberdorfer@yahoo.de', 'Irina', 'rog_irina@mail.ru', '', 'Liebes Schatzi,<br />\r\nschenke dir diesen Rosenstrauß und umarme dich mein liebe Irina. Ich bin glücklich das du weider gut angekommen bist und ich hoffe das es dir gesundheitlich auch wieder besser geht.<br />\r\nIch habe heute nachmittag geschlafen und hoffe bis zum Sonntag, spätestens bis Mittwoch wieder fit zu sein. Bei uns gibt es momentan eine Grippewelle und da habe ich mich wohl angesteckt. Es ist aber ok, denn man muß das beste daraus machen. Man muß in den Körper hinein horchen-hast du gesagt-ich mache das eigentlich immer und lebe relativ gesund. Sogar das Rauchen habe ich reduziert. Aber man darf auch nicht übertreiben, zu gesund ist auch nicht optimal. Es sind unsere Gene die unser Schicksal zum großen Teil bestimmen. Die geistige und körperliche Arbeit darf nicht vernachlässigt werden. Du machst es gut, genauso wie ich. Man muß mit dem Herzen sehen-die Menschen, die Natur, die Tiere und am Boden bleiben, bescheiden sein und Freude an einer Blume, die blüht, haben.<br />\r\nWir beide haben viel Gemeinsamkeiten und ich bin glücklich, das es so ist, mein Schatz.<br />\r\nEs kommt bald der Abend mit dir und deinen Lieben, auf das freue ich mich.<br />\r\nIch küsse dich mein Schatz und wünsche dir einen schönen Abend. Ich werde heute Radio Sewastopl mit Nachrichten und viel Musik hören. Ich liebe es und fühle mich sehr wohl dabei. Kerzen werden mich mit meinen Gedanken an dich begleiten und eine romantische Stimmung entstehen lassen. Das wird mich schneller gesunden lassen, wenn du bei mir bist. ', '1234', '2012-03-29 17:10:50'),
	(611, 'HanniBaal', 'efant.terrible@gmx.de', 'Alex mein Stinki', 'rakshashar@web.de', '', 'Huhu mein Hasi :-)<br />\r\nIch liebe dich *knutsch*<br />\r\ndeine HanniBaal', '7889', '2012-04-26 22:26:54'),
	(612, 'Dein Detlef', 'Detlef@Familie-Dieckmann.com', 'Meine Liebesgöttin', 'ka.baituschi@gmx.de', '', 'Guten Abend, mein Mondscheinengel,<br />\r\n<br />\r\nmit pastosem Duktus sehr filigran aufgetragen schenkst Du meiner Herzenswelt die schönsten Farben.<br />\r\n<br />\r\nDurch Dich, mein Schatz, spreche all die Blumen in ihren schönen Details wieder zu mir.<br />\r\n<br />\r\nWeil es Dich gibt, geht mir alles so leicht von der Hand.<br />\r\n<br />\r\nMeine Kathi verleiht Flügel.<br />\r\n<br />\r\nMeine liebe Maus, ich brauche Dich, begehre Dich und liebe Dich.<br />\r\n<br />\r\nHab einen nicht so stressigen Abend.<br />\r\n<br />\r\nBis nachher. Spätestens um 23 Uhr bin ich daheim und auf Skype aktiv.<br />\r\n<br />\r\nEinen sehr innigen Kuss.<br />\r\n<br />\r\nDein<br />\r\n<br />\r\nDetlef<br />\r\n', '2240', '2012-05-16 18:10:58'),
	(613, 'Claudia', 'claudia@enjoyliving.at', 'Bela', 'bela@virag-keg.com', '', '', '1830', '2012-05-18 08:23:39'),
	(614, 'Petra', 'petra.deimling@gmx.at', 'Leander', 'fotokainz@gmx.at', '', '...........und somit werd ich dich auch niemals vergessen können!<br />\r\n<br />\r\n1000 Küsse an Dich damit auch ich nicht in vergessenheit gerate!<br />\r\n<br />\r\npetra', '4039', '2012-06-04 09:14:20'),
	(615, 'Hausapro', 'bhauser.hauser28@gmail.com', 'Rene', 'r.arzberger@tsn.at', '', '', '2190', '2012-06-27 13:01:56'),
	(616, 'MA', 'christabartek@yahoo.de', 'Oliver', 'oliver.bartek@aon.at', '', '', '5876', '2012-08-28 10:47:58'),
	(617, 'Christa', 'christabartek@yahoo.de', 'Renate', 'renate.krska@chello.at', '', 'gestern, heute und morgen und<br />\r\n<br />\r\nübermorgen...............', '1145', '2012-08-28 10:51:57'),
	(618, 'Claudia', 'claudia@enjoyliving.at', 'clauda', 'claudia@enjoyliving.at', '', 'sd fsf sfsf sf', '8855', '2012-08-29 10:44:46'),
	(619, 'Virag', 'bela@virag-keg.com', 'Bela', 'bela@virag-keg.com', '', 'Das ist der Text.', '1011', '2012-08-31 10:37:29'),
	(620, 'virag', 'bela@virag-keg.com', 'bela', 'bela@virag-keg.com', '', 'text', '3536', '2012-08-31 11:37:00'),
	(621, 'virag', 'bela@virag-keg.com', 'bela', 'bela@virag-keg.com', '', 'text', '8983', '2012-08-31 11:37:31'),
	(622, 'Claudia Virag-Sulzenbacher', 'claudia@enjoyliving.at', 'bela', 'bela@virag-keg.com', '', 'swefsdf', '4498', '2012-08-31 11:39:43'),
	(623, 'Tine', 'tine_bulla@yahoo.de', 'Tobi', 'tngeppert@hotmail.com', '', 'Kitschikitschkitsch. Aber ich will das mal testen, bevor ich es auf Facebook ankündige, mein Traumprinz!!!! ', '9810', '2012-09-16 18:56:57'),
	(624, 'Klaudia', 'malek-d@web.de', 'Chaminda', 'rasian-a@web.de', '', 'ICH LIEBE DICH!', '6102', '2013-01-27 15:04:58'),
	(625, 'Klaudia', 'malek-d@web.de', 'Chaminda', 'rasian-a@web.de', '', 'Ich liebe Dich!', '5142', '2013-01-27 15:07:02'),
	(626, 'Bianca', 'biancajaeger100@gmail.at', 'Tomi', 'thomas.jaeger2@gmail.com', '', '', '2979', '2013-01-30 19:15:19'),
	(627, 'Sandra', 'sandra.maria.rainer@hotmail.com', 'Schatzi', 'manfred.totter@aon.at', '', 'Lieber Schatz!<br />\r\n<br />\r\nIch wünsch dir alles liebe zum Valentinstag! KUSS', '4298', '2013-02-14 09:24:30'),
	(628, 'Luigi', '7777777@online.de', 'Schatzi', 'margaretespann@online.de', '', '', '8652', '2013-02-21 17:15:24'),
	(629, 'Kuno Hanisch', 'prinz-hanisch@gmx.net', 'Ingrid Hanisch', 'I.hanisch1@gmx.de', '', '', '3376', '2013-04-01 16:57:17'),
	(630, 'Marie', 'dmaus@hotmail.de', 'fee', 'Traumfeee@hotmail.de', '', 'Hallo meine Liebe', '4713', '2013-04-11 09:37:33'),
	(631, 'Monikaaa', 'moexx@web.de', 'Aliksan', 'dilsan@hotmaul.de', '', '', '1234', '2013-06-15 16:51:55'),
	(632, 'Mom', 'servusz@yahoo.com', 'Margi', 'margit.reinisch@gmail.com', '', '', '1167', '2013-06-22 22:09:17'),
	(633, 'Petra', 'petzraberger66@gmx.at', 'Walter', 'hinterleitner@hinterleitner.com', '', '', '3326', '2013-06-26 20:02:20'),
	(634, 'Franziska Fladenhofer', 'franziska.fladenhofer@gmx.at', 'Heinrich Lehdorfer', 'heinrich.lehdorfer@jello.at', '', 'Lieber Heinzi!<br />\r\n<br />\r\nAlles Liebe und Gute wünschen Dir<br />\r\n<br />\r\nFranzi u. Heini', '3552', '2013-07-10 12:15:59'),
	(635, 'Rolf', 'Rolf.Appeldorn@webde', 'Rolf', 'Rolf.Appeldorn@webde', '', 'Test', '3495', '2013-08-22 17:59:44'),
	(636, 'marcela cerno', 'marcelacerno@hotmail.com', 'patricia pospichal', 'patricia.pospichal@gmx.at', '', '', '7497', '2013-08-26 13:52:16');
/*!40000 ALTER TABLE `ecards_post` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
