-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.pagetype_default_style_tag_text
CREATE TABLE IF NOT EXISTS `pagetype_default_style_tag_text` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `element_layout_ID` int(11) NOT NULL,
  `default_style_tag` text COLLATE utf8_unicode_ci NOT NULL,
  `editor` set('FCK','TXT') COLLATE utf8_unicode_ci NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `element_layout_ID` (`element_layout_ID`),
  CONSTRAINT `FK_pagetype_default_style_tag_text_element_layout` FOREIGN KEY (`element_layout_ID`) REFERENCES `element_layout` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.pagetype_default_style_tag_text: ~74 rows (ungefähr)
/*!40000 ALTER TABLE `pagetype_default_style_tag_text` DISABLE KEYS */;
INSERT INTO `pagetype_default_style_tag_text` (`ID`, `element_layout_ID`, `default_style_tag`, `editor`, `sort`, `comment`) VALUES
	(1, 1, 'titel', 'TXT', 10, NULL),
	(2, 2, 'einleitung', 'TXT', 10, NULL),
	(3, 4, 'artikelbeschriftung', 'TXT', 10, NULL),
	(4, 5, 'advertorial', 'TXT', 10, NULL),
	(5, 11, 'infobox', 'FCK', 10, 'Zusatzinfo'),
	(7, 11, 'artikeltext', 'TXT', 20, 'Webtipps'),
	(10, 11, 'infoboxzwischenheads', 'TXT', 40, 'Beschriftung mehr zum Thema'),
	(11, 10, 'titel', 'TXT', 10, NULL),
	(12, 10, 'einleitung', 'TXT', 20, NULL),
	(13, 10, 'artikeltext', 'FCK', 30, NULL),
	(14, 19, '*', 'FCK', 10, NULL),
	(15, 20, 'artikeltext', 'FCK', 10, NULL),
	(16, 31, '*', 'TXT', 10, NULL),
	(17, 12, 'titel', 'TXT', 10, NULL),
	(18, 12, 'einleitung', 'TXT', 20, NULL),
	(19, 12, 'artikeltext', 'TXT', 30, NULL),
	(21, 4, 'artikelbeschriftung', 'TXT', 20, 'Hier wird die drop-down box gespeichet...'),
	(22, 11, 'artikeltext', 'FCK', 30, 'Haupttext'),
	(23, 41, '*', 'TXT', 10, 'menu_teaser_config_id'),
	(24, 41, '*', 'TXT', 20, 'menu_teaser_number_menus (f Auto-Teaser)'),
	(25, 47, '*', 'TXT', 10, 'menu_teaser_config_id'),
	(26, 47, '*', 'TXT', 20, 'menu_teaser_number_menus (f Auto-Teaser)'),
	(27, 49, '*', 'TXT', 10, 'Typ: entweder Menu_ID oder href'),
	(28, 49, '*', 'TXT', 20, 'Menu_ID'),
	(29, 49, '*', 'TXT', 30, 'href'),
	(30, 50, 'artikeltext', 'FCK', 20, 'Einleitung f Gewinnspiel (direkt unter den Reitern'),
	(31, 50, 'artikeltext', 'FCK', 30, 'Darstellung der Preise'),
	(32, 50, 'artikeltext', 'TXT', 10, 'ID des Gewinnspiels'),
	(35, 50, 'artikeltext', 'FCK', 40, 'Einleitung Gallerie'),
	(36, 50, 'artikeltext', 'FCK', 50, 'Gewinnertext + Darstellung'),
	(37, 50, 'artikeltext', 'TXT', 60, 'Teilnahmebedingungen'),
	(38, 51, '*', 'TXT', 10, 'Nr Teasers pro Zeile (ID rowsetup)'),
	(39, 51, '*', 'TXT', 20, 'Bild needed'),
	(40, 51, '*', 'TXT', 30, 'read flag needed'),
	(41, 51, '*', 'TXT', 40, 'Einleitung needed'),
	(42, 51, '*', 'TXT', 50, 'Parent needed'),
	(43, 51, '*', 'TXT', 60, 'Bild Layout (ID img pos)'),
	(44, 51, '*', 'TXT', 70, 'Auswahlmethode (ID select method)'),
	(45, 51, '*', 'TXT', 80, 'Truncate y/n'),
	(46, 51, '*', 'TXT', 90, 'Truncate length'),
	(47, 51, '*', 'TXT', 100, 'Truncate forced'),
	(48, 51, '*', 'TXT', 110, 'Sort 1 (ID sort methods)'),
	(49, 51, '*', 'TXT', 120, 'Sort 2 (ID sort methods)'),
	(50, 51, '*', 'TXT', 130, 'Sort 3 (ID sort methods)'),
	(51, 51, '*', 'TXT', 140, 'Nr. levels manual'),
	(52, 51, '*', 'TXT', 150, 'Nr. entries manual'),
	(53, 51, '*', 'TXT', 160, 'textwrap y/n'),
	(54, 51, '*', 'TXT', 170, 'Layout ID'),
	(55, 51, '*', 'TXT', 180, 'Rollup'),
	(56, 51, '*', 'TXT', 190, 'Thin separators'),
	(57, 52, '*', 'TXT', 10, '1=Fotostrecken URL (y/n), 2=default URL'),
	(58, 55, '*', 'TXT', 10, NULL),
	(59, 56, '*', 'FCK', 10, NULL),
	(60, 51, '*', 'TXT', 200, 'Start ID for Auto-selectors'),
	(61, 54, '*', 'TXT', 10, 'Nr Teasers pro Zeile (ID rowsetup)'),
	(62, 54, '*', 'TXT', 20, 'Bild needed'),
	(63, 54, '*', 'TXT', 30, 'read flag needed'),
	(64, 54, '*', 'TXT', 40, 'Einleitung needed'),
	(65, 54, '*', 'TXT', 50, 'Parent needed'),
	(66, 54, '*', 'TXT', 60, 'Bild Layout (ID img pos)'),
	(67, 54, '*', 'TXT', 70, 'Auswahlmethode (ID select method)'),
	(68, 54, '*', 'TXT', 80, 'Truncate y/n'),
	(69, 54, '*', 'TXT', 90, 'Truncate length'),
	(70, 54, '*', 'TXT', 100, 'Truncate forced'),
	(71, 54, '*', 'TXT', 110, 'Sort 1 (ID sort methods)'),
	(72, 54, '*', 'TXT', 120, 'Sort 2 (ID sort methods)'),
	(73, 54, '*', 'TXT', 130, 'Sort 3 (ID sort methods)'),
	(74, 54, '*', 'TXT', 140, 'Nr. levels manual'),
	(75, 54, '*', 'TXT', 150, 'Nr. entries manual'),
	(76, 54, '*', 'TXT', 160, 'textwrap y/n'),
	(77, 54, '*', 'TXT', 170, 'Layout ID'),
	(78, 54, '*', 'TXT', 180, 'Rollup'),
	(79, 54, '*', 'TXT', 190, 'Thin separators'),
	(80, 54, '*', 'TXT', 200, 'Start ID for Auto-selectors');
/*!40000 ALTER TABLE `pagetype_default_style_tag_text` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
