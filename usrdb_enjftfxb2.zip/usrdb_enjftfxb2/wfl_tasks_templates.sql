-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.wfl_tasks_templates
CREATE TABLE IF NOT EXISTS `wfl_tasks_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wfl_id` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `description` text NOT NULL,
  `user_group_id` int(11) NOT NULL,
  `due_date_distance` int(11) NOT NULL,
  `task_type` tinytext NOT NULL,
  `decision_a_task` int(11) NOT NULL,
  `decision_b_task` int(11) NOT NULL,
  `is_menu_id` int(11) NOT NULL,
  `money_value` decimal(2,0) NOT NULL,
  `next_task_id` int(50) NOT NULL,
  `comment_type` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.wfl_tasks_templates: 7 rows
/*!40000 ALTER TABLE `wfl_tasks_templates` DISABLE KEYS */;
INSERT INTO `wfl_tasks_templates` (`id`, `wfl_id`, `title`, `description`, `user_group_id`, `due_date_distance`, `task_type`, `decision_a_task`, `decision_b_task`, `is_menu_id`, `money_value`, `next_task_id`, `comment_type`) VALUES
	(1, 1, 'Vorschlag unterbreiten', 'Ã¶', 13, 7, 'Start', 2, 2, 0, 0, 2, 2),
	(2, 1, 'Akzeptanzentscheidung', 'Ã¶llllÃ¤Der EL Redakteur entscheidet ob er den Artikel anlegen will, oder nicht.', 8, 7, 'Entscheidung', 9, 3, 0, 0, 0, 1),
	(3, 1, 'Vorschlag abgelehnt', 'Der User sieht das Feedback, dass der Artikel abgelehnt wurde.', 13, 7, 'Ende', 1, 0, 0, 0, 0, 0),
	(9, 1, 'Artikel schreiben', 'Der Nutzer schreibt den Artikel', 13, 7, 'Aktion', 2, 2, 1, 0, 10, 0),
	(11, 1, 'Artikel Abnahme', 'Der Redakteur entscheidet Ã¼ber die Artikel abnahme.', 8, 7, 'Entscheidung', 12, 9, 0, 0, 2, 2),
	(10, 1, 'Artikel zum review', 'Der Nutzer schickt den geschriebenen Artikel an die Redaktion zur Abnahme', 13, 7, 'Aktion', 2, 2, 1, 0, 11, 0),
	(12, 1, 'Artikel wurde publiziert', 'Der Artikel wurde publiziert.', 8, 7, 'Ende', 2, 2, 0, 20, 2, 1);
/*!40000 ALTER TABLE `wfl_tasks_templates` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
