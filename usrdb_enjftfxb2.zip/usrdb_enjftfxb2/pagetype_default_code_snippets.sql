-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.pagetype_default_code_snippets
CREATE TABLE IF NOT EXISTS `pagetype_default_code_snippets` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `element_layout_ID` int(11) NOT NULL,
  `default_element_content_code_url` text COLLATE utf8_unicode_ci NOT NULL,
  `default_element_content_code_admin_url` text COLLATE utf8_unicode_ci NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_pagetype_default_code_snippets_element_layout` (`element_layout_ID`),
  CONSTRAINT `FK_pagetype_default_code_snippets_element_layout` FOREIGN KEY (`element_layout_ID`) REFERENCES `element_layout` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.pagetype_default_code_snippets: ~10 rows (ungefähr)
/*!40000 ALTER TABLE `pagetype_default_code_snippets` DISABLE KEYS */;
INSERT INTO `pagetype_default_code_snippets` (`ID`, `element_layout_ID`, `default_element_content_code_url`, `default_element_content_code_admin_url`, `sort`, `comment`) VALUES
	(1, 3, 'code_elements/subcontent.php', 'admin/code_elements/admin_subcontent.php', 10, NULL),
	(3, 6, 'code_elements/infobox_mehr_zum_Thema.php', '', 10, NULL),
	(4, 7, 'code_elements/footer.php', '', 10, NULL),
	(5, 8, 'code_elements/comments.php', 'admin/code_elements/admin_comments.php', 10, NULL),
	(6, 9, 'code_elements/google_adwords.php', '', 10, NULL),
	(8, 11, 'code_elements/infobox_mehr_zum_Thema.php', '', 10, 'mehr zum Thema'),
	(9, 28, 'code_elements/subcontentKapitel.php', 'admin/code_elements/admin_subcontentKapitel.php', 10, NULL),
	(10, 11, 'includes/advertorial.php', 'admin/includes/admin_advertorial.php', 20, 'Advertorial'),
	(11, 11, 'includes/tags.php', '', 30, 'Tags'),
	(12, 58, 'code_elements/google_adwords_contentempfehlung.php', '', 10, NULL);
/*!40000 ALTER TABLE `pagetype_default_code_snippets` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
