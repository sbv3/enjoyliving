-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Prozedur usrdb_enjftfxb2.statistik_pc_id_create_visitor
DELIMITER //
CREATE DEFINER=`enjftfxb2`@`%` PROCEDURE `statistik_pc_id_create_visitor`(IN `pc_id` BIGINT)
BEGIN
declare done,Anz,visitor_id INT default 0;
      DECLARE cur CURSOR FOR
		 select count(*) as Anz from visitor_pc_id where visitor_pc_id.pc_id=pc_id limit 1;
      OPEN cur;
       FETCH cur INTO Anz;
       IF Anz='0' then 
        insert into visitor (id) values ("");
        set visitor_id=LAST_INSERT_ID();
		  insert into visitor_pc_id (pc_id,visitor_id) values (pc_id,visitor_id); 
		 end if;
      CLOSE cur;
END//
DELIMITER ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
