-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.menu_teaser_config_layout
CREATE TABLE IF NOT EXISTS `menu_teaser_config_layout` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `description` tinytext COLLATE utf8_unicode_ci,
  `scope` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `help` tinytext COLLATE utf8_unicode_ci,
  `slider_mode` int(11) DEFAULT NULL COMMENT '1=slider, 2=slider preview',
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.menu_teaser_config_layout: 4 rows
/*!40000 ALTER TABLE `menu_teaser_config_layout` DISABLE KEYS */;
INSERT INTO `menu_teaser_config_layout` (`id`, `description`, `scope`, `help`, `slider_mode`, `sort`) VALUES
	(1, 'list', 'main', 'Standardansicht: alle Teaser in einer n-spaltigen Liste', NULL, 10),
	(2, 'slider', 'main', 'Alle Teaser in einem horizontalen Slider', 1, 20),
	(3, 'sl_edit', 'main', 'Das Layout wird um die Ausmaße der Slider buttons verschmälert', 2, 30),
	(4, 'list_s', 'seitencontent', 'Standardansicht: alle Teaser in einer n-spaltigen Liste', 0, 10);
/*!40000 ALTER TABLE `menu_teaser_config_layout` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
