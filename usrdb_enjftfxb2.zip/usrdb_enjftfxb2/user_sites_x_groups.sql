-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.user_sites_x_groups
CREATE TABLE IF NOT EXISTS `user_sites_x_groups` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `sites_ID` int(10) DEFAULT '0',
  `groups_ID` int(10) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `FK_user_sites_x_groups_sites` (`sites_ID`),
  KEY `FK_user_sites_x_groups_user_groups` (`groups_ID`),
  CONSTRAINT `FK_user_sites_x_groups_sites` FOREIGN KEY (`sites_ID`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_user_sites_x_groups_user_groups` FOREIGN KEY (`groups_ID`) REFERENCES `user_groups` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.user_sites_x_groups: ~11 rows (ungefähr)
/*!40000 ALTER TABLE `user_sites_x_groups` DISABLE KEYS */;
INSERT INTO `user_sites_x_groups` (`ID`, `sites_ID`, `groups_ID`) VALUES
	(12, 2, 3),
	(14, 4, 4),
	(19, 1, 8),
	(20, 4, 9),
	(33, 1, 1),
	(42, 2, 12),
	(43, 3, 14),
	(44, 1, 15),
	(45, 5, 15),
	(46, 3, 15),
	(47, 2, 15);
/*!40000 ALTER TABLE `user_sites_x_groups` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
