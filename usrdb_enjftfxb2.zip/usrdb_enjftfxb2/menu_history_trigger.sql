-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Trigger usrdb_enjftfxb2.menu_history
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='';
DELIMITER //
CREATE TRIGGER `menu_history` BEFORE UPDATE ON `menu` FOR EACH ROW BEGIN
insert into menu_history ( 
h_id, h_xxx_hierarchy_level,h_description, h_page_finished, h_pagetype, h_search_type,h_parent_id,h_sort,h_display, h_exklusiver_seitencontent, h_exklusiver_sponsorbanner, h_active_startdate,h_active_enddate, h_active, h_metatag_title,h_metatag_keywords,h_metatag_description,h_up_date)
select 
id, xxx_hierarchy_level,description, page_finished, pagetype, search_type,parent_id,sort,display, exklusiver_seitencontent, exklusiver_sponsorbanner, active_startdate,active_enddate, active, metatag_title,metatag_keywords,metatag_description,up_date from menu where id=OLD.id
;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
