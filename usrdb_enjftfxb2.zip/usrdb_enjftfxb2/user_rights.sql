-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.user_rights
CREATE TABLE IF NOT EXISTS `user_rights` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `xxxx_eingepflegt` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.user_rights: ~33 rows (ungefähr)
/*!40000 ALTER TABLE `user_rights` DISABLE KEYS */;
INSERT INTO `user_rights` (`ID`, `description`, `xxxx_eingepflegt`) VALUES
	(1, 'enter_admin', 1),
	(2, 'edit_menu_seitenattribute', 1),
	(3, 'enter_verwaiste_google_URL', 1),
	(4, 'enter_admin_menu', NULL),
	(5, 'enter_page_content', 1),
	(7, 'create_menu', 1),
	(8, 'delete_menu', 1),
	(9, 'edit_element_content', NULL),
	(10, 'edit_element', NULL),
	(11, 'create_element', 1),
	(12, 'delete_element', NULL),
	(17, 'edit_users', 1),
	(18, 'share_menu_ids', 1),
	(19, 'take_menu_ids_from_pool', 1),
	(20, 'edit_shared_content', 1),
	(21, 'edit_non_mastered_pages', 1),
	(22, 'edit_seitencontent', 1),
	(23, 'edit_sponsorbanner', 1),
	(24, 'call_menu_id_selector', 1),
	(26, 'call_img_editor', 1),
	(27, 'enter_newsletter/gewinnspiele', 1),
	(28, 'edit_display_status', NULL),
	(29, 'edit_description', NULL),
	(30, 'edit_active_status', NULL),
	(31, 'edit_active_dates', NULL),
	(32, 'edit_searchgroup', NULL),
	(33, 'enter_metatags', NULL),
	(34, 'enter_googleurls', NULL),
	(35, 'enter_changemother', NULL),
	(36, 'edit_sort', 1),
	(38, 'edit_kampagnen', NULL),
	(39, 'edit_kopf_fuss', 1),
	(40, 'enter_workflow_admin', 1);
/*!40000 ALTER TABLE `user_rights` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
