-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.visitor_credentials
CREATE TABLE IF NOT EXISTS `visitor_credentials` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `visitor_id` int(10) NOT NULL DEFAULT '0',
  `username` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_email` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_hash` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_id` int(11) DEFAULT NULL,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`,`user_email`,`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.visitor_credentials: 2 rows
/*!40000 ALTER TABLE `visitor_credentials` DISABLE KEYS */;
INSERT INTO `visitor_credentials` (`id`, `visitor_id`, `username`, `password`, `user_email`, `password_reset_hash`, `site_id`, `createdate`) VALUES
	(6, 14708, 'bela', '$2nzZSp7AbPrc', 'bela@virag-keg.com', NULL, 1, '2013-02-24 20:55:36'),
	(7, 14708, 'bela1', '$2v7rTPgoCbr.', 'bela@virag-keg.com', 'DQ9gJti8++sZnmHeIf8yg5VHspBeXoD9NTfOV7VyCXY=', 1, '2013-02-24 20:55:36');
/*!40000 ALTER TABLE `visitor_credentials` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
