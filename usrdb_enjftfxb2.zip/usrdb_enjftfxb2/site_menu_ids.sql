-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.site_menu_ids
CREATE TABLE IF NOT EXISTS `site_menu_ids` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_id` int(10) NOT NULL DEFAULT '0',
  `menu_id` int(10) NOT NULL DEFAULT '0',
  `kopf_fuss` tinytext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `FK_site_menu_ids_sites` (`site_id`),
  KEY `FK_site_menu_ids_menu` (`menu_id`),
  CONSTRAINT `FK_site_menu_ids_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`),
  CONSTRAINT `FK_site_menu_ids_sites` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.site_menu_ids: ~26 rows (ungefähr)
/*!40000 ALTER TABLE `site_menu_ids` DISABLE KEYS */;
INSERT INTO `site_menu_ids` (`id`, `site_id`, `menu_id`, `kopf_fuss`) VALUES
	(1, 1, 5471, 'kopf'),
	(2, 1, 5472, 'kopf'),
	(3, 1, 5474, 'kopf'),
	(4, 1, 5475, 'kopf'),
	(5, 1, 5477, 'fuss'),
	(6, 1, 5478, 'fuss'),
	(7, 1, 5489, 'fuss'),
	(8, 1, 5490, 'fuss'),
	(9, 1, 5520, 'fuss'),
	(10, 1, 5521, 'fuss'),
	(11, 1, 5479, 'fuss'),
	(13, 1, 230, 'kopf'),
	(14, 4, 7579, 'kopf'),
	(15, 2, 8021, 'fuss'),
	(16, 5, 5471, 'kopf'),
	(17, 5, 5472, 'kopf'),
	(18, 5, 5474, 'kopf'),
	(19, 5, 5475, 'kopf'),
	(20, 5, 5477, 'fuss'),
	(21, 5, 5478, 'fuss'),
	(22, 5, 5489, 'fuss'),
	(23, 5, 5490, 'fuss'),
	(24, 5, 5520, 'fuss'),
	(25, 5, 5521, 'fuss'),
	(26, 5, 5479, 'fuss'),
	(27, 5, 230, 'kopf');
/*!40000 ALTER TABLE `site_menu_ids` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
