-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.practiceTBL
CREATE TABLE IF NOT EXISTS `practiceTBL` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `power` char(8) DEFAULT NULL,
  `vehicle` varchar(40) DEFAULT NULL,
  `url` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.practiceTBL: ~4 rows (ungefähr)
/*!40000 ALTER TABLE `practiceTBL` DISABLE KEYS */;
INSERT INTO `practiceTBL` (`id`, `power`, `vehicle`, `url`) VALUES
	(1, 'electric', 'RC10B5 Team Kit, 1:10 scale buggy', 'http://www.teamassociated.com/cars_and_trucks/RC10B5/Team/'),
	(2, 'electric', 'SC10RS RTR, 1:10 scale short course truc', 'http://www.teamassociated.com/cars_and_trucks/SC10/Race-Spec/'),
	(3, 'nitro', 'RC8.2RS RTR, 1:8 scale buggy', 'http://www.teamassociated.com/cars_and_trucks/RC8.2/RSRTR/'),
	(4, 'nitro', 'RC8T Factory Team Kit, 1:8 scale truck', 'http://www.teamassociated.com/cars_and_trucks/RC8T/Factory_Team/');
/*!40000 ALTER TABLE `practiceTBL` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
