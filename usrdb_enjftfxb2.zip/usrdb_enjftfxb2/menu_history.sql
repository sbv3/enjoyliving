-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.menu_history
CREATE TABLE IF NOT EXISTS `menu_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `h_id` int(11) NOT NULL,
  `h_xxx_hierarchy_level` int(11) NOT NULL,
  `h_description` text COLLATE utf8_unicode_ci NOT NULL,
  `h_page_finished` set('0','1') COLLATE utf8_unicode_ci NOT NULL,
  `h_url` text COLLATE utf8_unicode_ci NOT NULL,
  `h_pagetype` text COLLATE utf8_unicode_ci NOT NULL,
  `h_search_type` char(50) COLLATE utf8_unicode_ci NOT NULL,
  `h_parent_id` int(11) NOT NULL,
  `h_sort` int(3) NOT NULL,
  `h_display` set('0','1') COLLATE utf8_unicode_ci NOT NULL,
  `h_exklusiver_seitencontent` set('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `h_exklusiver_sponsorbanner` set('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `h_active_startdate` date NOT NULL,
  `h_active_enddate` date NOT NULL,
  `h_active` char(1) CHARACTER SET latin1 COLLATE latin1_german2_ci NOT NULL DEFAULT 'D',
  `h_metatag_title` text CHARACTER SET latin1 COLLATE latin1_german1_ci,
  `h_metatag_keywords` text CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL,
  `h_metatag_description` text CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL,
  `h_up_date` timestamp NULL DEFAULT NULL,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Daten Export vom Benutzer nicht ausgewählt
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
