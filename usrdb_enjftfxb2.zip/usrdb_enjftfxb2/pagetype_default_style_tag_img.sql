-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.pagetype_default_style_tag_img
CREATE TABLE IF NOT EXISTS `pagetype_default_style_tag_img` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `element_layout_ID` int(11) NOT NULL,
  `default_type` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `sort` int(11) NOT NULL,
  `breite` int(10) DEFAULT NULL,
  `hoehe` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_pagetype_default_style_tag_img_element_layout` (`element_layout_ID`),
  CONSTRAINT `FK_pagetype_default_style_tag_img_element_layout` FOREIGN KEY (`element_layout_ID`) REFERENCES `element_layout` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.pagetype_default_style_tag_img: ~6 rows (ungefähr)
/*!40000 ALTER TABLE `pagetype_default_style_tag_img` DISABLE KEYS */;
INSERT INTO `pagetype_default_style_tag_img` (`ID`, `element_layout_ID`, `default_type`, `sort`, `breite`, `hoehe`) VALUES
	(1, 11, 'artikelbild_infobox', 10, 200, 0),
	(2, 10, 'fotostrecke_gross', 10, 0, 0),
	(3, 20, 'artikelbild', 10, 200, 0),
	(4, 13, 'buchtipp', 10, 120, 120),
	(5, 12, 'fotostrecke_klein', 10, 0, 0),
	(6, 49, 'image_teaser', 10, 0, 0);
/*!40000 ALTER TABLE `pagetype_default_style_tag_img` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
