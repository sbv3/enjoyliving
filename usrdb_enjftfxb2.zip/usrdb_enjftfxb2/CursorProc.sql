-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Prozedur usrdb_enjftfxb2.CursorProc
DELIMITER //
CREATE DEFINER=`enjftfxb2`@`%` PROCEDURE `CursorProc`()
BEGIN
DECLARE  no_more_products, quantity_in_stock INT DEFAULT 0;
DECLARE  prd_code VARCHAR(255);
DECLARE  cur_product CURSOR FOR
SELECT  PRGCODE FROM xxx;
DECLARE  CONTINUE HANDLER FOR NOT FOUND 
SET  no_more_products = 1;


CREATE  TABLE infologs (
Id int(11) NOT NULL AUTO_INCREMENT,
Msg varchar(255) NOT NULL,
PRIMARY KEY (Id)
);
OPEN  cur_product;

FETCH  cur_product INTO prd_code;
REPEAT 
SELECT  quantityInStock INTO quantity_in_stock
FROM  products
WHERE  PRGCODE = prd_code;

IF  quantity_in_stock < 100 THEN
INSERT  INTO infologs(msg)
VALUES  (prd_code);
END  IF;
FETCH  cur_product INTO prd_code;
UNTIL  no_more_products = 1
END REPEAT;
CLOSE  cur_product;
SELECT *  FROM infologs;
DROP TABLE  infologs;
END//
DELIMITER ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
