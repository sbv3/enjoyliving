-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.menu_teaser_config_rowsetup
CREATE TABLE IF NOT EXISTS `menu_teaser_config_rowsetup` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_id` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `description` tinytext COLLATE utf8_unicode_ci,
  `scope` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `help` tinytext COLLATE utf8_unicode_ci,
  `col_nr` int(10) DEFAULT NULL,
  `teasercopycols` int(10) DEFAULT NULL,
  `containerwidth` int(10) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.menu_teaser_config_rowsetup: ~8 rows (ungefähr)
/*!40000 ALTER TABLE `menu_teaser_config_rowsetup` DISABLE KEYS */;
INSERT INTO `menu_teaser_config_rowsetup` (`id`, `site_id`, `description`, `scope`, `help`, `col_nr`, `teasercopycols`, `containerwidth`, `sort`) VALUES
	(1, ',1,2,3,4,', '1', 'main', 'Einspaltig', 1, 98, 620, 10),
	(2, ',1,2,3,4,', '2', 'main', 'Zweispaltig', 2, 46, 307, 20),
	(3, ',1,2,3,4,', '3', 'main', 'Dreispaltig', 3, 29, 203, 30),
	(4, ',1,2,3,4,', '1_s', 'seitencontent', 'Einspaltig', 1, 46, 300, 10),
	(5, ',1,2,3,4,', '2_s', 'seitencontent', 'Zweispaltig', 2, 20, 147, 20),
	(11, ',5,', '1', 'main', 'Einspaltig', 1, 98, 938, 10),
	(12, ',5,', '2', 'main', 'Zweispaltig', 2, 46, 465, 20),
	(13, ',5,', '3', 'main', 'Dreispaltig', 3, 29, 307, 30);
/*!40000 ALTER TABLE `menu_teaser_config_rowsetup` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
