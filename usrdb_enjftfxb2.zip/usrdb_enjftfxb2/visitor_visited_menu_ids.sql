-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.visitor_visited_menu_ids
CREATE TABLE IF NOT EXISTS `visitor_visited_menu_ids` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) DEFAULT '0',
  `visitor_id` int(10) DEFAULT '0',
  `count` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `visitor_id` (`visitor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.visitor_visited_menu_ids: 5 rows
/*!40000 ALTER TABLE `visitor_visited_menu_ids` DISABLE KEYS */;
INSERT INTO `visitor_visited_menu_ids` (`id`, `menu_id`, `visitor_id`, `count`) VALUES
	(1, 230, 14708, 1),
	(2, 208, 14708, 2),
	(3, 3942, 14708, 2),
	(4, 3941, 14708, 2),
	(5, 3480, 14708, 2);
/*!40000 ALTER TABLE `visitor_visited_menu_ids` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
