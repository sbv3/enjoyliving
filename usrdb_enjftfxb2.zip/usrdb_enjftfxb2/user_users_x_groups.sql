-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.user_users_x_groups
CREATE TABLE IF NOT EXISTS `user_users_x_groups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `users_ID` int(11) NOT NULL,
  `groups_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `groups_ID` (`groups_ID`),
  KEY `users_ID` (`users_ID`),
  CONSTRAINT `FK_user_users_x_groups_user_groups` FOREIGN KEY (`groups_ID`) REFERENCES `user_groups` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_user_users_x_groups_user_users` FOREIGN KEY (`users_ID`) REFERENCES `user_users` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.user_users_x_groups: ~16 rows (ungefähr)
/*!40000 ALTER TABLE `user_users_x_groups` DISABLE KEYS */;
INSERT INTO `user_users_x_groups` (`ID`, `users_ID`, `groups_ID`) VALUES
	(1, 1, 1),
	(2, 2, 1),
	(3, 3, 1);
/*!40000 ALTER TABLE `user_users_x_groups` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
