-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Prozedur usrdb_enjftfxb2.googleurl_count
DELIMITER //
CREATE DEFINER=`enjftfxb2`@`%` PROCEDURE `googleurl_count`(IN `googleurl_in` tinytEXT, IN `menu_id_in` INT, IN `bot_in` INT, IN `useragent_in` tinytEXT, IN `site_id_in` INT)
    MODIFIES SQL DATA
BEGIN
 DECLARE count_result,id_result,finished int;
 DECLARE cursor_name CURSOR FOR select count,id from googleurl_statistik where googleurl=googleurl_in and site_id=site_id_in and menu_id=menu_id_in and date=date(now()) and hour=hour(now()) and useragent=useragent_in and bot=bot_in limit 1; 
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
 
 OPEN cursor_name;
 	FETCH cursor_name INTO count_result, id_result;
 CLOSE cursor_name;

 IF  finished = 1 THEN
 insert into googleurl_statistik (googleurl,menu_id,count,bot,useragent, site_id) values (googleurl_in,menu_id_in,'1',bot_in,useragent_in,site_id_in);
 ELSE
 update googleurl_statistik set count=count_result+1 where id=id_result;
 end if;
END//
DELIMITER ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
