-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.user_groups_x_site_pool
CREATE TABLE IF NOT EXISTS `user_groups_x_site_pool` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_id` int(10) NOT NULL,
  `group_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__user_groups` (`group_id`),
  KEY `site_id_group_id` (`site_id`,`group_id`),
  CONSTRAINT `FK__sites` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK__user_groups` FOREIGN KEY (`group_id`) REFERENCES `user_groups` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.user_groups_x_site_pool: ~21 rows (ungefähr)
/*!40000 ALTER TABLE `user_groups_x_site_pool` DISABLE KEYS */;
INSERT INTO `user_groups_x_site_pool` (`id`, `site_id`, `group_id`) VALUES
	(46, 1, 1),
	(34, 1, 3),
	(35, 1, 4),
	(27, 1, 8),
	(40, 1, 11),
	(42, 1, 12),
	(48, 1, 14),
	(51, 1, 15),
	(19, 2, 1),
	(30, 2, 3),
	(36, 2, 4),
	(38, 2, 8),
	(43, 2, 12),
	(55, 2, 15),
	(49, 3, 14),
	(52, 3, 15),
	(37, 4, 4),
	(47, 4, 9),
	(44, 4, 11),
	(50, 4, 14),
	(53, 5, 15);
/*!40000 ALTER TABLE `user_groups_x_site_pool` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
