-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.sites
CREATE TABLE IF NOT EXISTS `sites` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `description` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subline` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host_string` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `menu_hierarchy_update_needed` int(11) DEFAULT NULL,
  `language` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo_url` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `favicon_url` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `managing_editor` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `webmaster` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_menu_id` int(10) DEFAULT NULL,
  `css_path` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_ad_client` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_ad_channel` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_ad_slot` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_ad_contentempfehlung` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_ad_slot_seitencontent` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `analytics_id` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banners` int(10) DEFAULT NULL,
  `seitencontent` int(10) DEFAULT NULL,
  `onsitestats` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `host_string` (`host_string`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.sites: ~5 rows (ungefähr)
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` (`id`, `description`, `subline`, `host_string`, `menu_hierarchy_update_needed`, `language`, `title`, `logo_url`, `favicon_url`, `managing_editor`, `webmaster`, `top_menu_id`, `css_path`, `google_ad_client`, `google_ad_channel`, `google_ad_slot`, `google_ad_contentempfehlung`, `google_ad_slot_seitencontent`, `analytics_id`, `banners`, `seitencontent`, `onsitestats`) VALUES
	(1, 'Enjoy Living', 'Das Online Magazin zum Thema Gesundheit, Entspannu', 'www.enjoyliving.at', 0, 'de-de', 'EnjoyLiving', 'http://www.enjoyliving.at/xml/logo.gif', '/site_12_1/css/el/favicon.ico', 'office@enjoyliving.at', 'technik@enjoyliving.at', 230, '/site_12_1/css/style.php', 'ca-pub-5166723294900636', '8714824668', '7049503333', '9030465890', '7167239099', 'UA-1282959-1', 1, 1, 1),
	(2, 'Purely Woman', 'Das Magazin für die Frau.', 'www.purelywoman.at', 0, 'de-de', 'PurelyWoman', 'http://www.purelywoman.at/site_12_1/css/pw/logo.png', '/site_12_1/css/pw/favicon.ico', 'office@purelywoman.at', 'technik@purelywoman.at', 1, '/site_12_1/css/style_pw.php', 'ca-pub-5166723294900636', '4509838383', '3903350414', NULL, '0359043823', 'UA-36322488-1', 1, 1, 0),
	(3, 'Garden und Living', 'Das Magazin für Haus und Garten', 'www.gardenandliving.at', 0, 'de-de', 'Garden & Living', 'http://www.mangoo.at/site_12_1/css/mangoo/logo.jpg', '/site_12_1/css/mangoo/favicon.ico', 'office@gardenandliving.at', 'technik@gardenandliving.at', 3, '/site_12_1/css/style_gl.php', 'ca-pub-5166723294900636', '8714824668', '7049503333', NULL, '7167239099', '', 0, 1, 0),
	(4, 'Mangoo', 'Das Magazin für Bela.', 'www.mangoo.at', 0, 'de-de', 'Mangoo', 'http://www.mangoo.at/site_12_1/css/mangoo/logo.jpg', '/site_12_1/css/mangoo/favicon.ico', 'office@mangoo.at', 'technik@mangoo.at', 8, '/site_12_1/css/style_mangoo.php', 'ca-pub-5166723294900636', '5795943897', '7049503333', NULL, '7049503333', '', 0, 1, 0),
	(5, 'Familie Spatz', 'Familie Spatz', 'www.familiespatz.at', 0, 'de-de', 'Familie Spatz', 'http://www.enjoyliving.at/site_12_1/css/fs/logo_web.png', '/site_12_1/css/el/favicon.ico', 'office@familiepsatz.at', 'technik@familiespatz.at', 11, '/site_12_1/css/style_familiespatz.php', 'ca-pub-5166723294900636', '8714824668', '7049503333', NULL, '7167239099', '', 0, 1, 0);
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
