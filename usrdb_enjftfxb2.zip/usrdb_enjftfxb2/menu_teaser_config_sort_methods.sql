-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.menu_teaser_config_sort_methods
CREATE TABLE IF NOT EXISTS `menu_teaser_config_sort_methods` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `description` tinytext COLLATE utf8_unicode_ci,
  `help` tinytext COLLATE utf8_unicode_ci,
  `sort` int(11) DEFAULT NULL,
  `table` tinytext COLLATE utf8_unicode_ci,
  `field` tinytext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.menu_teaser_config_sort_methods: 6 rows
/*!40000 ALTER TABLE `menu_teaser_config_sort_methods` DISABLE KEYS */;
INSERT INTO `menu_teaser_config_sort_methods` (`id`, `description`, `help`, `sort`, `table`, `field`) VALUES
	(1, 'Createdate der Seite', 'Es wird das Erstelldaum der Seite genommen. Das ist jenes Datum, an welchem die Menu_ID angelegt wurde (unabhängig von sharing, etc.) ACHTUNG: Viele haben einen Wert "0000-00-00"', 10, 'm', 'createdate desc'),
	(2, 'Createdate des Magazin Eintrags', 'Es wird das Erstelldaum des Magazineintrags genommen. Das ist jenes Datum, an welchem die Menu_ID einem Magazin erstmalig zugeordnet wurde (quasi wann der Menüeintrag das erste Mal erschienen ist). Bei nicht-gesharten Artikeln ist das in der Regel ident ', 20, 'mh', 'createdate desc'),
	(3, 'Startdate des Magazin Eintrags', 'Es wird das Startdatum des Artikels herangezogen. Es ist das händisch eingegebene Datum.', 30, 'mh', 'active_startdate desc'),
	(4, 'Enddate des Magazin Eintrags', 'Es wird das Enddatum des Artikels herangezogen. Es ist das händisch eingegebene Datum.', 40, 'mh', 'active_enddate'),
	(5, 'Artikel-sort', 'Es wird die Sortierreihenfolge des Artikels genommen', 50, 'mh', 'sort desc'),
	(0, 'keep', 'Es wird die Sortierreihenfolge beibehalten, in welcher die Datensätze gefunden wurden.', 5, 'keep', 'none');
/*!40000 ALTER TABLE `menu_teaser_config_sort_methods` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
