-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.kampagnen_element
CREATE TABLE IF NOT EXISTS `kampagnen_element` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `kampagnen_code_id` int(10) DEFAULT NULL,
  `element_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_kampagnen_menu_kampagnen_code` (`kampagnen_code_id`),
  KEY `FK_kampagnen_element_element` (`element_id`),
  CONSTRAINT `FK_kampagnen_element_element` FOREIGN KEY (`element_id`) REFERENCES `element` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_kampagnen_menu_kampagnen_code` FOREIGN KEY (`kampagnen_code_id`) REFERENCES `kampagnen_code` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.kampagnen_element: ~18 rows (ungefähr)
/*!40000 ALTER TABLE `kampagnen_element` DISABLE KEYS */;
INSERT INTO `kampagnen_element` (`id`, `kampagnen_code_id`, `element_id`) VALUES
	(86, 54, 31394),
	(94, 44, 31648),
	(95, 56, 31645),
	(104, 44, 31837),
	(105, 45, 31839),
	(106, 44, 31841),
	(107, 45, 31842),
	(108, 45, 31846),
	(140, 48, 34747),
	(189, 84, 36173),
	(192, 86, 37005),
	(193, 87, 37006),
	(197, 91, 40468),
	(202, 86, 40822),
	(203, 94, 40824),
	(204, 95, 40828),
	(205, 96, 40829);
/*!40000 ALTER TABLE `kampagnen_element` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
