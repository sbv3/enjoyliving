-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Prozedur usrdb_enjftfxb2.menu_hierarchy_make_paths
DELIMITER //
CREATE DEFINER=`enjftfxb2`@`%` PROCEDURE `menu_hierarchy_make_paths`(IN `iroot` INT, IN `ilevel` INT, IN `ipath` vARCHAR(50), IN `isite_id` INT, IN `parent_is_menu_hierarchy` TINYTEXT, IN `parent_is_active_hierarchy` INT)
BEGIN
  DECLARE irows,imenu_id,iparent_id,ichildcount,done,iactive,parent_is_active_hierarchy_test INT DEFAULT 0;
  DECLARE imenu,parent_is_menu_hierarchy_test tinytext;
  SET irows = ( SELECT COUNT(*) FROM menu_hierarchy WHERE parent_id=iroot );  
  IF irows > 0 THEN
    BEGIN
      DECLARE cur CURSOR FOR
        SELECT
          t.menu_id,
			 t.parent_id,
			 (SELECT COUNT(*) FROM menu_hierarchy WHERE menu_hierarchy.parent_id=menu_hierarchy.menu_id) AS childcount, 
			 concat(ipath,'/',menu_id) as ipath, 
			 site_id as isite_id,
			 if ((active_startdate<=now() or active_startdate='0000-00-00') and (active_enddate>=now() or active_enddate='0000-00-00') and active='A', 1, 0) as iactive,
			 if (display='1','1','0') as imenu
        FROM menu_hierarchy t
        WHERE t.parent_id=iroot and t.site_id=isite_id
        ORDER BY childcount<>0,t.sort;
      DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;
      set parent_is_menu_hierarchy_test=parent_is_menu_hierarchy;
      set parent_is_active_hierarchy_test=parent_is_active_hierarchy;
      OPEN cur;
      WHILE NOT done DO
        FETCH cur INTO imenu_id,iparent_id,ichildcount,ipath,isite_id,iactive,imenu;
          IF (parent_is_menu_hierarchy_test='1' and imenu='1') THEN set parent_is_menu_hierarchy='1'; else set parent_is_menu_hierarchy='0'; END IF;
       
       
       
          
			 IF (parent_is_active_hierarchy_test=1 and iactive=1) THEN set parent_is_active_hierarchy=1; else set parent_is_active_hierarchy=0; END IF;
       
       
       
          
        IF NOT done THEN
          set @absolute_sort_order=@absolute_sort_order+1;
          update menu_hierarchy set level=ilevel, pfad=ipath, absolute_sort=@absolute_sort_order, is_menu_hierarchy=parent_is_menu_hierarchy, is_active_hierarchy=parent_is_active_hierarchy where menu_id=imenu_id and site_id=isite_id;
          IF ichildcount > 0 and imenu_id!=0 THEN
            CALL menu_hierarchy_make_paths( imenu_id, ilevel + 1,ipath,isite_id,parent_is_menu_hierarchy,parent_is_active_hierarchy);
          END IF;
        END IF;
      END WHILE;
      CLOSE cur;
    END;
  END IF;
END//
DELIMITER ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
