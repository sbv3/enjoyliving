-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von View usrdb_enjftfxb2.img_update
-- Entferne temporäre Tabelle und erstelle die eigentliche View
DROP TABLE IF EXISTS `img_update`;
CREATE ALGORITHM=UNDEFINED DEFINER=`enjftfxb2`@`%` SQL SECURITY DEFINER VIEW `img_update` AS select `menu_teaser`.`element_id` AS `element_id`,`element`.`menu_id` AS `menu_id`,`assets`.`filename` AS `filename`,`menu_teaser`.`teaser_asset_id` AS `teaser_asset_id`,`menu_teaser_config_rowsetup_X_img_pos`.`rowsetup_id` AS `rowsetup_id`,`menu_teaser_config_rowsetup_X_img_pos`.`img_pos_id` AS `img_pos_id`,`menu_teaser_config_rowsetup_X_img_pos`.`width` AS `width`,`menu_teaser_config_rowsetup_X_img_pos`.`height` AS `height`,`assets`.`breite` AS `breite`,`assets`.`hoehe` AS `hoehe`,`menu_teaser`.`asset_h_offset` AS `asset_h_offset`,`menu_teaser`.`asset_v_offset` AS `asset_v_offset`,`menu_teaser`.`asset_h_offset_percent` AS `asset_h_offset_percent`,`menu_teaser`.`asset_v_offset_percent` AS `asset_v_offset_percent`,(-(`menu_teaser`.`asset_v_offset`) / (`menu_teaser_config_rowsetup_X_img_pos`.`height` - ((`menu_teaser_config_rowsetup_X_img_pos`.`width` / `assets`.`breite`) * `assets`.`hoehe`))) AS `v_neu` from (((((`menu_teaser` join `element`) join `element_content_text` `text1`) join `element_content_text` `text2`) join `menu_teaser_config_rowsetup_X_img_pos`) join `assets`) where ((`menu_teaser`.`element_id` = `element`.`id`) and (`element`.`id` = `text1`.`element_id`) and (`element`.`id` = `text2`.`element_id`) and (`text1`.`sort` = 10) and (`text2`.`sort` = 60) and (`menu_teaser_config_rowsetup_X_img_pos`.`rowsetup_id` = `text1`.`text`) and (`menu_teaser_config_rowsetup_X_img_pos`.`img_pos_id` = `text2`.`text`) and (`menu_teaser`.`teaser_asset_id` = `assets`.`ID`) and (`element`.`element_layout_id` = 51) and (`menu_teaser`.`asset_v_offset` < 0));
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
