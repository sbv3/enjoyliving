-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.videos
CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `videoDate` date NOT NULL,
  `quelle` text COLLATE utf8_unicode_ci NOT NULL,
  `videoID` decimal(10,0) NOT NULL,
  `videoTitel` text COLLATE utf8_unicode_ci NOT NULL,
  `videoTeaser` text COLLATE utf8_unicode_ci NOT NULL,
  `videoBild` text COLLATE utf8_unicode_ci NOT NULL,
  `videoGruppe` text COLLATE utf8_unicode_ci NOT NULL,
  `videoLaenge` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.videos: 6 rows
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
INSERT INTO `videos` (`id`, `videoDate`, `quelle`, `videoID`, `videoTitel`, `videoTeaser`, `videoBild`, `videoGruppe`, `videoLaenge`) VALUES
	(1, '2012-08-14', 'snackTV', 573092, 'Promis ohne BH', 'Als Irina Shayk ohne BH in einem flatteringen und einschultrigen Kleid spazieren geht, suchten wir bei den Promis den besten Style ohne BH.', '', 'promis', '00:01:26'),
	(2, '2012-08-14', 'snackTV', 572423, 'Fashion Ausrutscher der Woche', 'Sophia Bush, Nikki Reed, Christa B. Allen und Marisol Nichols befinden sich diese Woche auf der Liste der "worst dressed women".', '', 'promis', '00:01:08'),
	(3, '2012-08-14', 'snackTV', 571055, 'Celebrity Summer Style', 'It may be hot in the city, but these famous ladies are looking super-cool!', '', 'promis', '00:02:22'),
	(4, '2012-08-14', 'snackTV', 567468, 'Monica Cruz in heißen Dessous', 'In einem Werbeclip für das Dessouslabel Agent Provocateur zeigt die Schwester von Penelopé Cruz, dass auch sie viel zu bieten hat.', '', 'promis', '00:02:31'),
	(5, '2012-08-14', 'snackTV', 565617, 'Stars in modischen schmalen Jeans', 'Von Eva Longoria über Anne Hathaway und Miranda Kerr, alle diese Stars tragen eng geschnittene Hosen, um ihre Beine lang und schlank aussehen zu lassen.', '', 'promis', '00:01:17'),
	(6, '2012-08-14', 'snackTV', 564395, 'Das richtige Kleid für jeden Typ', 'Wir haben die richtigen Kleider-Tipps für jeden Typ von Frau.', '', 'fashion', '00:04:57');
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
