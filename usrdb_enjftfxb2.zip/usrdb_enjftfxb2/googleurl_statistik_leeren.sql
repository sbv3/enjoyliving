-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Ereignis usrdb_enjftfxb2.googleurl_statistik_leeren
DELIMITER //
CREATE DEFINER=`enjftfxb2`@`%` EVENT `googleurl_statistik_leeren` ON SCHEDULE EVERY 1 DAY STARTS '2016-02-05 02:30:00' ON COMPLETION PRESERVE ENABLE DO BEGIN
insert into googleurl_statistik_backup select * from googleurl_statistik where date <subdate(date(now()), 1);
delete from googleurl_statistik where date <subdate(date(now()), 1);
OPTIMIZE TABLE `usrdb_enjftfxb2`.`googleurl_statistik`;
OPTIMIZE TABLE `usrdb_enjftfxb2`.`googleurl_statistik_backup`;
END//
DELIMITER ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
