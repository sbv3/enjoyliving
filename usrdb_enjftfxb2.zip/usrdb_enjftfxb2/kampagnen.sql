-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.kampagnen
CREATE TABLE IF NOT EXISTS `kampagnen` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_id` int(10) NOT NULL,
  `description` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startdate` date DEFAULT '0000-00-00',
  `enddate` date DEFAULT '0000-00-00',
  `createdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_kampagnen_sites` (`site_id`),
  CONSTRAINT `FK_kampagnen_sites` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.kampagnen: ~23 rows (ungefähr)
/*!40000 ALTER TABLE `kampagnen` DISABLE KEYS */;
INSERT INTO `kampagnen` (`id`, `site_id`, `description`, `startdate`, `enddate`, `createdate`, `up_date`) VALUES
	(13, 1, 'Interactive', '2000-01-01', '2020-01-01', '2011-08-07 17:06:07', '2012-05-21 16:13:52'),
	(14, 1, 'Sponsorbanner', '2011-10-01', '2015-01-01', '2011-08-08 18:58:26', '2013-02-26 11:43:21'),
	(15, 1, 'Viversum Horoskope', '0000-00-00', '0000-00-00', '2011-10-05 16:12:46', '2012-05-21 16:13:52'),
	(16, 1, 'paarship', '2011-02-23', '2012-02-23', '2011-10-05 17:34:04', '2012-05-21 16:13:52'),
	(17, 1, 'sport2000', '2010-01-01', '2014-12-31', '2011-10-05 17:49:51', '2012-05-21 16:13:52'),
	(19, 1, 'test', '0000-00-00', '0000-00-00', '2011-10-25 20:45:39', '2012-05-21 16:13:52'),
	(20, 1, 'Car2Go', '0000-00-00', '0000-00-00', '2011-12-04 15:56:00', '2012-05-21 16:13:52'),
	(23, 1, 'Eigene Werbeformate', '0000-00-00', '0000-00-00', '2012-02-01 09:10:39', '2012-05-21 16:13:52'),
	(24, 1, 'Affilinet', '0000-00-00', '0000-00-00', '2012-02-09 09:01:01', '2012-05-21 16:13:52'),
	(25, 1, 'Redpinnaple', '0000-00-00', '0000-00-00', '2012-05-14 15:29:14', '2012-05-21 16:13:52'),
	(27, 4, 'Openinventory', '0000-00-00', '0000-00-00', '2012-05-21 16:23:41', '2012-07-12 15:00:15'),
	(35, 1, 'Sommerfoto2012_design3000', '2012-01-01', '2012-12-31', '2012-08-07 18:23:49', '2012-11-11 18:05:10'),
	(36, 2, 'google', '2012-01-01', '2018-01-01', '2012-09-27 10:25:42', '2012-09-27 10:26:06'),
	(38, 1, 'inhouse', '2012-01-01', '2020-12-12', '2012-12-11 15:41:33', '2012-12-11 15:41:55'),
	(39, 1, 'adscale', '2012-01-01', '2020-01-01', '2013-02-02 17:43:48', '2013-02-02 17:44:13'),
	(40, 1, 'GoogleAdserver', '2013-01-01', '2016-01-01', '2013-02-26 14:45:33', '2013-02-26 14:46:11'),
	(41, 1, 'Fotostrecken Break', '2013-01-01', '2018-01-01', '2013-02-28 16:55:57', '2013-02-28 16:56:27'),
	(42, 2, 'Interactive', '2012-01-01', '2018-01-01', '2013-03-11 12:44:21', '2013-03-11 12:44:41'),
	(43, 2, 'REspalte', '2012-01-01', '2018-01-01', '2013-03-11 12:44:42', '2013-03-11 12:45:26'),
	(44, 1, 'Themensponsoring', '2012-01-01', '2020-01-01', '2013-03-15 11:20:24', '2013-03-15 11:20:49'),
	(45, 1, 'Advertorial', '2012-01-01', '2020-01-01', '2013-04-17 12:04:54', '2013-04-19 14:02:45'),
	(46, 1, 'Medium Rectangle_rechteSpalte', '2013-01-01', '2020-01-01', '2013-06-02 12:13:27', '2013-06-02 12:14:02'),
	(47, 1, 'PinterestVerifizieren', '0000-00-00', '0000-00-00', '2014-12-02 09:38:17', '2014-12-02 09:38:27');
/*!40000 ALTER TABLE `kampagnen` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
