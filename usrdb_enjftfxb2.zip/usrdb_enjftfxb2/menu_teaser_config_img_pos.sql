-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.menu_teaser_config_img_pos
CREATE TABLE IF NOT EXISTS `menu_teaser_config_img_pos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `description` tinytext COLLATE utf8_unicode_ci,
  `site_id` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scope` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `help` tinytext COLLATE utf8_unicode_ci,
  `sort` int(10) DEFAULT '0',
  `allowed_rowsetup_id` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `text_overlaps` int(11) DEFAULT NULL,
  `textbox_float` tinytext COLLATE utf8_unicode_ci,
  `textbox_distance` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.menu_teaser_config_img_pos: ~9 rows (ungefähr)
/*!40000 ALTER TABLE `menu_teaser_config_img_pos` DISABLE KEYS */;
INSERT INTO `menu_teaser_config_img_pos` (`id`, `description`, `site_id`, `scope`, `help`, `sort`, `allowed_rowsetup_id`, `text_overlaps`, `textbox_float`, `textbox_distance`) VALUES
	(1, 'links', ',1,2,3,4,', 'main', 'Bild wird links vom Text angezeigt', 10, '1|2', NULL, 'right', 10),
	(2, 'oben', ',1,2,3,4,', 'main', 'Bild wird oberhalb vom Text angezeigt', 20, '1|2|3', NULL, 'none', 0),
	(3, 'unter Text', ',1,2,3,4,', 'main', 'Das Bild liegt unter dem Text, ein grauer Balken wird eingeblendet', 30, '1|2|3', 1, 'none', 0),
	(4, 'links_s', ',1,2,3,4,', 'seitencontent', 'Bild wird links vom Text angezeigt', 5, '4|5', NULL, 'right', 5),
	(5, 'oben_s', ',1,2,3,4,', 'seitencontent', 'Bild wird oberhalb vom Text angezeigt', 20, '4|5', NULL, 'none', 0),
	(6, 'unter Text_s', ',1,2,3,4,', 'seitencontent', 'Das Bild liegt unter dem Text, ein grauer Balken wird eingeblendet', 30, '4|5', 1, 'none', 0),
	(11, 'links', ',5,', 'main', 'Bild wird links vom Text angezeigt', 10, '11|12', NULL, 'right', 10),
	(12, 'oben', ',5,', 'main', 'Bild wird oberhalb vom Text angezeigt', 20, '11|12|13', NULL, 'none', 0),
	(13, 'unter Text', ',5,', 'main', 'Das Bild liegt unter dem Text, ein grauer Balken wird eingeblendet', 30, '11|12|13', 1, 'none', 0);
/*!40000 ALTER TABLE `menu_teaser_config_img_pos` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
