-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.menu_teaser_config_rowsetup_X_img_pos
CREATE TABLE IF NOT EXISTS `menu_teaser_config_rowsetup_X_img_pos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rowsetup_id` int(10) DEFAULT NULL,
  `img_pos_id` int(10) DEFAULT NULL,
  `width` int(10) DEFAULT NULL,
  `height` int(10) DEFAULT NULL,
  `textbox_style_head` tinytext COLLATE utf8_unicode_ci,
  `textbox_style_head_grey` tinytext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rowsetup_id` (`rowsetup_id`,`img_pos_id`),
  KEY `FK_rowsetup_X_img_pos_menu_teaser_config_img_pos` (`img_pos_id`),
  CONSTRAINT `FK_rowsetup_X_img_pos_menu_teaser_config_img_pos` FOREIGN KEY (`img_pos_id`) REFERENCES `menu_teaser_config_img_pos` (`id`),
  CONSTRAINT `FK_rowsetup_X_img_pos_menu_teaser_config_rowsetup` FOREIGN KEY (`rowsetup_id`) REFERENCES `menu_teaser_config_rowsetup` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.menu_teaser_config_rowsetup_X_img_pos: ~22 rows (ungefähr)
/*!40000 ALTER TABLE `menu_teaser_config_rowsetup_X_img_pos` DISABLE KEYS */;
INSERT INTO `menu_teaser_config_rowsetup_X_img_pos` (`id`, `rowsetup_id`, `img_pos_id`, `width`, `height`, `textbox_style_head`, `textbox_style_head_grey`) VALUES
	(1, 1, 1, 150, 85, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(2, 1, 2, NULL, 150, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(3, 1, 3, NULL, 150, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(5, 2, 1, 132, 80, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(6, 2, 2, NULL, NULL, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(7, 2, 3, NULL, NULL, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(8, 3, 1, 80, 46, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(9, 3, 2, NULL, 116, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(10, 3, 3, 203, 116, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(11, 4, 4, 80, 46, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(13, 4, 5, NULL, 150, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(14, 4, 6, NULL, 150, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(15, 5, 4, 50, 28, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(16, 5, 5, NULL, 72, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(17, 5, 6, NULL, 72, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(45, 11, 11, 150, 85, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(46, 11, 12, NULL, 550, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(47, 11, 13, NULL, 550, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(48, 12, 11, 132, 80, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(49, 12, 12, NULL, NULL, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(50, 12, 13, NULL, NULL, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(51, 13, 11, 80, 46, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(52, 13, 12, NULL, 200, 'teaser_einleitung', 'teaser_einleitung_grey'),
	(53, 13, 13, 203, 200, 'teaser_einleitung', 'teaser_einleitung_grey');
/*!40000 ALTER TABLE `menu_teaser_config_rowsetup_X_img_pos` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
