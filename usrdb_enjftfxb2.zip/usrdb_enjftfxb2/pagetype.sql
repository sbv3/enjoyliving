-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.pagetype
CREATE TABLE IF NOT EXISTS `pagetype` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `element_layout_id` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `search_type` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `available_to` tinytext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `FK_pagetype_element_layout` (`element_layout_id`),
  CONSTRAINT `FK_pagetype_element_layout` FOREIGN KEY (`element_layout_id`) REFERENCES `element_layout` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.pagetype: ~71 rows (ungefähr)
/*!40000 ALTER TABLE `pagetype` DISABLE KEYS */;
INSERT INTO `pagetype` (`ID`, `description`, `element_layout_id`, `sort`, `search_type`, `available_to`) VALUES
	(1, 'Artikel mit Infobox links', 1, 10, 'Artikel', ',1,2,6,3,5,'),
	(2, 'Artikel mit Infobox links', 2, 20, '', ',1,2,6,3,5,'),
	(3, 'Artikel mit Infobox links', 11, 30, '(NULL)', ',1,2,6,3,5,'),
	(4, 'Artikel mit Infobox links', 4, 40, '(NULL)', ',1,2,6,3,5,'),
	(5, 'Artikel mit Infobox links', 5, 50, '(NULL)', ',1,2,6,3,5,'),
	(6, 'Artikel mit Infobox links', 7, 60, '(NULL)', ',1,2,6,3,5,'),
	(7, 'Artikel mit Infobox links', 8, 70, '(NULL)', ',1,2,6,3,5,'),
	(8, 'Artikel mit Infobox links', 9, 80, '(NULL)', ',1,2,6,3,5,'),
	(9, 'Subcontent Master', 1, 10, 'Artikel', ',1,2,6,3,5,'),
	(10, 'Subcontent Master', 2, 20, NULL, ',1,2,6,3,5,'),
	(11, 'Subcontent Master', 3, 30, NULL, ',1,2,6,3,5,'),
	(12, 'Subcontent Master', 4, 40, NULL, ',1,2,6,3,5,'),
	(13, 'Subcontent Master', 5, 50, NULL, ',1,2,6,3,5,'),
	(15, 'Subcontent Master', 7, 70, NULL, ',1,2,6,3,5,'),
	(16, 'Subcontent Master', 8, 80, NULL, ',1,2,6,3,5,'),
	(17, 'Subcontent Master', 9, 90, NULL, ',1,2,6,3,5,'),
	(18, 'Subcontent Fotostrecke groß', 10, 10, 'Subseiten', ',1,2,6,3,5,'),
	(19, 'Übersichtsseite', 1, 10, 'Übersichtsseiten', ',1,2,6,3,5,'),
	(21, 'Übersichtsseite', 2, 20, NULL, ',1,2,6,3,5,'),
	(23, 'Übersichtsseite', 41, 30, NULL, ',1,2,6,3,5,'),
	(24, 'Übersichtsseite', 9, 40, NULL, ',1,2,6,3,5,'),
	(25, 'blank_FCK', 19, 10, NULL, ',1,2,6,3,5,'),
	(27, 'Artikel mit Bild rechts oben', 1, 10, 'Artikel', ',1,2,6,3,5,'),
	(28, 'Artikel mit Bild rechts oben', 2, 20, NULL, ',1,2,6,3,5,'),
	(29, 'Artikel mit Bild rechts oben', 20, 30, NULL, ',1,2,6,3,5,'),
	(30, 'Artikel mit Bild rechts oben', 4, 40, NULL, ',1,2,6,3,5,'),
	(31, 'Artikel mit Bild rechts oben', 5, 50, NULL, ',1,2,6,3,5,'),
	(32, 'Artikel mit Bild rechts oben', 7, 60, NULL, ',1,2,6,3,5,'),
	(33, 'Artikel mit Bild rechts oben', 8, 70, NULL, ',1,2,6,3,5,'),
	(34, 'Artikel mit Bild rechts oben', 9, 80, NULL, ',1,2,6,3,5,'),
	(35, 'blank_TXT', 31, 10, NULL, ',1,2,6,3,5,'),
	(37, 'Buchtipp', 1, 10, 'Artikel', ',1,2,6,3,5,'),
	(38, 'Buchtipp', 31, 20, NULL, ',1,2,6,3,5,'),
	(39, 'Buchtipp', 13, 30, NULL, ',1,2,6,3,5,'),
	(40, 'Buchtipp', 7, 40, NULL, ',1,2,6,3,5,'),
	(41, 'Buchtipp', 9, 50, NULL, ',1,2,6,3,5,'),
	(42, 'Pressemitteilung', 1, 10, 'Pressemitteilung', ',1,2,6,3,5,'),
	(43, 'Pressemitteilung', 2, 20, NULL, ',1,2,6,3,5,'),
	(44, 'Pressemitteilung', 20, 30, NULL, ',1,2,6,3,5,'),
	(46, 'Pressemitteilung', 9, 50, NULL, ',1,2,6,3,5,'),
	(48, 'Subcontent Fotostrecke klein', 12, 10, 'Tools', ',1,2,6,3,5,'),
	(49, 'Subcontent Master (Kapitel)', 1, 10, 'Artikel', ',1,2,6,3,5,'),
	(50, 'Subcontent Master (Kapitel)', 2, 20, NULL, ',1,2,6,3,5,'),
	(51, 'Subcontent Master (Kapitel)', 28, 30, NULL, ',1,2,6,3,5,'),
	(52, 'Subcontent Master (Kapitel)', 4, 40, NULL, ',1,2,6,3,5,'),
	(53, 'Subcontent Master (Kapitel)', 5, 50, NULL, ',1,2,6,3,5,'),
	(54, 'Subcontent Master (Kapitel)', 7, 70, NULL, ',1,2,6,3,5,'),
	(55, 'Subcontent Master (Kapitel)', 8, 80, NULL, ',1,2,6,3,5,'),
	(56, 'Subcontent Master (Kapitel)', 9, 90, NULL, ',1,2,6,3,5,'),
	(57, 'Subcontent Fotostrecke groß', 4, 20, 'Subseiten', ',1,2,6,3,5,'),
	(58, 'Fotogewinnspiel', 1, 10, 'Titel', ',1,2,6,3,5,'),
	(59, 'Fotogewinnspiel', 2, 20, NULL, ',1,2,6,3,5,'),
	(60, 'Fotogewinnspiel', 5, 30, NULL, ',1,2,6,3,5,'),
	(61, 'Fotogewinnspiel', 7, 50, NULL, ',1,2,6,3,5,'),
	(62, 'Fotogewinnspiel', 50, 40, NULL, ',1,2,6,3,5,'),
	(63, 'Fotogewinnspiel', 8, 60, NULL, ',1,2,6,3,5,'),
	(64, 'Fotogewinnspiel', 9, 70, NULL, ',1,2,6,3,5,'),
	(65, 'Übersichtsseite', 1, 10, 'Übersichtsseite', ',4,'),
	(66, 'Übersichtsseite', 2, 20, '(NULL)', ',4,'),
	(67, 'Übersichtsseite', 41, 30, '(NULL)', ',4,'),
	(69, 'Übersichtsseite', 18, 40, '(NULL)', ',4,'),
	(70, 'Übersichtsseite', 7, 50, '(NULL)', ',4,'),
	(71, 'Übersichtsseite', 9, 60, '(NULL)', ',4,'),
	(72, 'Artikel mit Bild rechts oben', 1, 10, 'Artikel', ',4,'),
	(73, 'Artikel mit Bild rechts oben', 2, 20, '(NULL)', ',4,'),
	(74, 'Artikel mit Bild rechts oben', 20, 30, '(NULL)', ',4,'),
	(75, 'Artikel mit Bild rechts oben', 4, 40, '(NULL)', ',4,'),
	(76, 'Artikel mit Bild rechts oben', 18, 50, '(NULL)', ',4,'),
	(77, 'Artikel mit Bild rechts oben', 8, 60, '(NULL)', ',4,'),
	(78, 'Artikel mit Bild rechts oben', 7, 70, '(NULL)', ',4,'),
	(79, 'Artikel mit Bild rechts oben', 9, 80, '(NULL)', ',4,');
/*!40000 ALTER TABLE `pagetype` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
