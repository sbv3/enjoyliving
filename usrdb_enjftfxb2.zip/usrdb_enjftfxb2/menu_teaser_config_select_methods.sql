-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.menu_teaser_config_select_methods
CREATE TABLE IF NOT EXISTS `menu_teaser_config_select_methods` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `description` tinytext COLLATE utf8_unicode_ci,
  `help` tinytext COLLATE utf8_unicode_ci,
  `sort` int(11) DEFAULT NULL,
  `manual_limitors` int(10) DEFAULT NULL,
  `auto_manual` tinytext COLLATE utf8_unicode_ci,
  `sibling_selection` tinytext COLLATE utf8_unicode_ci,
  `sibling_selection_incl_menus` int(10) DEFAULT NULL,
  `remove_duplicates` int(10) DEFAULT NULL,
  `manual_start_point` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.menu_teaser_config_select_methods: 6 rows
/*!40000 ALTER TABLE `menu_teaser_config_select_methods` DISABLE KEYS */;
INSERT INTO `menu_teaser_config_select_methods` (`id`, `description`, `help`, `sort`, `manual_limitors`, `auto_manual`, `sibling_selection`, `sibling_selection_incl_menus`, `remove_duplicates`, `manual_start_point`) VALUES
	(1, 'manual', 'Der Menu-id selector wird angezeigt und bestimmt die Sortierreihenfolge', 10, 0, 'manual', NULL, NULL, 1, NULL),
	(2, 'all directs', 'Es werden alle direkten Siblings ausgewählt', 20, 0, 'auto', 'direct', NULL, 1, 1),
	(3, 'siblings (menus)', 'Es werden über mehrere Ebenen hinweg Einträge gesucht', 30, 2, 'auto', 'multi', 1, 1, 1),
	(4, 'sibling (o.menus)', 'Es werden über mehrere Ebenen hinweg Einträge gesucht', 40, 2, 'auto', 'multi', 0, 1, 1),
	(5, 'similar', 'Es werden ähnliche Einträge gesucht (zuerst aus der eigenen Rubrik und darunter, wenn dort aber nicht genug gefunden werden, dann basierend auf Keyword so viele wie halt gesucht werden)', 50, 1, 'auto', 'similar', NULL, 1, 1),
	(6, 'recent', 'Es werden die zuletzt angezeigten Seiten gefunden', 60, 1, 'auto', 'recent', NULL, 0, NULL);
/*!40000 ALTER TABLE `menu_teaser_config_select_methods` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
