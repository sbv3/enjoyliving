-- --------------------------------------------------------
-- Host:                         enjoyliving.at
-- Server Version:               5.6.38-1 - (Debian)
-- Server Betriebssystem:        debian-linux-gnu
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle usrdb_enjftfxb2.element_layout
CREATE TABLE IF NOT EXISTS `element_layout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `active` int(10) NOT NULL DEFAULT '1',
  `available_to` tinytext COLLATE utf8_unicode_ci,
  `php_snippet` text COLLATE utf8_unicode_ci NOT NULL,
  `php_admin_snippet` text COLLATE utf8_unicode_ci NOT NULL,
  `kampagnentauglich` int(11) NOT NULL,
  `nr_content_text` int(11) NOT NULL,
  `nr_content_menu` int(11) NOT NULL,
  `nr_content_img` int(11) NOT NULL,
  `nr_content_code` int(11) NOT NULL,
  `block_sharing` int(10) DEFAULT NULL,
  `site_specific` int(10) NOT NULL,
  `singular` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle usrdb_enjftfxb2.element_layout: ~53 rows (ungefähr)
/*!40000 ALTER TABLE `element_layout` DISABLE KEYS */;
INSERT INTO `element_layout` (`id`, `type`, `description`, `active`, `available_to`, `php_snippet`, `php_admin_snippet`, `kampagnentauglich`, `nr_content_text`, `nr_content_menu`, `nr_content_img`, `nr_content_code`, `block_sharing`, `site_specific`, `singular`) VALUES
	(1, 'in padding', 'Titel', 1, ',1,2,4,6,3,5,', 'includes/text.php', 'admin/includes/admin_text.php', 0, 1, 0, 0, 0, 0, 0, 0),
	(2, 'in padding', 'Einleitung', 1, ',1,2,4,6,3,5,', 'includes/text.php', 'admin/includes/admin_text.php', 0, 1, 0, 0, 0, 0, 0, 0),
	(3, 'in padding', 'Subcontent', 1, ',1,2,6,3,5,', 'includes/code.php', 'admin/includes/admin_code.php', 0, 0, 0, 0, 1, 0, 0, 1),
	(4, 'in padding', 'Autor', 1, ',1,2,4,6,3,5,', 'includes/artikelbeschriftung.php', 'admin/includes/admin_artikelbeschriftung.php', 0, 2, 0, 0, 0, 0, 0, 0),
	(5, 'in padding', 'Advertorial f Artikel', 1, ',1,2,4,6,3,5,', 'includes/advertorial.php', 'admin/includes/admin_advertorial.php', 1, 0, 0, 0, 0, 0, 0, 0),
	(6, 'in padding', 'Mehr zum thema', 1, ',1,2,4,6,3,5,', 'includes/code.php', 'admin/includes/admin_code.php', 0, 0, 0, 0, 1, 0, 0, 0),
	(7, 'in padding', 'Footer', 1, ',1,2,4,6,3,5,', 'includes/code.php', 'admin/includes/admin_code.php', 0, 0, 0, 0, 1, 0, 0, 1),
	(8, 'in padding', 'Comments', 1, ',1,2,4,6,3,5,', 'includes/code.php', 'admin/includes/admin_code.php', 0, 0, 0, 0, 1, 0, 0, 1),
	(9, 'in padding', 'Google adwords f Artikel', 1, ',1,2,4,6,3,5,', 'includes/code.php', 'admin/includes/admin_code.php', 0, 0, 0, 0, 1, 0, 0, 0),
	(10, 'in padding', 'Fotostrecke groß subpage', 1, ',1,2,6,3,5,', 'includes/fotostrecke_gross_subpage.php', 'admin/includes/admin_fotostrecke_gross_subpage.php', 0, 3, 0, 1, 0, 0, 0, 0),
	(11, 'in padding', 'Artikel_mit_infobox_links', 1, ',1,2,4,6,3,5,', 'includes/artikel_mit_infobox_links.php', 'admin/includes/admin_artikel_mit_infobox_links.php', 1, 4, 0, 1, 2, 0, 0, 0),
	(12, 'in padding', 'Fotostrecke klein subpage', 1, ',1,2,6,3,5,', 'includes/fotostrecke_klein_subpage.php', 'admin/includes/admin_fotostrecke_klein_subpage.php', 0, 3, 0, 1, 0, 0, 0, 0),
	(13, 'in padding', 'Buchtipps', 1, ',1,2,4,6,3,5,', 'includes/buchtipp.php', 'admin/includes/admin_buchtipp.php', 0, 0, 0, 0, 0, 0, 0, 0),
	(16, 'in padding', 'Übersichtsseite single image', 2, ',1,2,6,3,5,', 'includes/uebersicht_single_img.php', 'admin/includes/admin_uebersicht_single_img.php', 0, 0, 0, 0, 0, 0, 0, 0),
	(17, 'in padding', 'Übersichtsseite dual image', 2, ',1,2,6,3,5,', 'includes/uebersicht_dual_img.php', 'admin/includes/admin_uebersicht_dual_img.php', 0, 0, 0, 0, 0, 0, 0, 0),
	(18, 'break padding', 'Separator', 1, ',1,2,4,6,3,5,', 'includes/separator.php', '', 0, 0, 0, 0, 0, 0, 0, 0),
	(19, 'in padding', 'Blank FCK', 1, ',1,2,4,6,3,5,', 'includes/text.php', 'admin/includes/admin_text.php', 0, 1, 0, 0, 0, 0, 0, 0),
	(20, 'in padding', 'Artikel mit Bild rechts oben', 1, ',1,2,4,6,3,5,', 'includes/artikel_Bild_rechts_oben.php', 'admin/includes/admin_artikel_Bild_rechts_oben.php', 0, 1, 0, 1, 0, 0, 0, 0),
	(22, 'seitencontent break padding', 'Seitencontent separator', 1, ',1,2,4,6,3,5,', 'includes/separator.php', '', 0, 0, 0, 0, 0, 0, 1, 0),
	(23, 'seitencontent in padding', 'Seitencontent google adwords', 1, ',1,2,4,6,3,5,', 'includes/seitencontent/seitencontent_google_adwords.php', '', 0, 0, 0, 0, 0, 0, 1, 0),
	(24, 'in padding', 'Biorythmus', 1, ',1,2,6,3,5,', 'includes/tools/biorhythmus.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(25, 'in padding', 'Sternzeichen', 1, ',1,2,6,3,5,', 'includes/tools/sternzeichen.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(26, 'in padding', 'Fruchtbarkeit', 1, ',1,2,6,3,5,', 'includes/tools/fruchtbarkeit.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(27, 'in padding', 'Kalorienverbrauch', 1, ',1,2,6,3,5,', 'includes/tools/kalorienverbrauch.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(28, 'in padding', 'Subcontent_Kapitel', 1, ',1,2,6,3,5,', 'includes/code.php', 'admin/includes/admin_code.php', 0, 0, 0, 0, 1, 0, 0, 1),
	(29, 'in padding', 'Dotted line', 1, ',1,2,4,6,3,5,', 'includes/dotted_line.php', '', 0, 0, 0, 0, 0, 0, 0, 0),
	(31, 'in padding', 'Blank TXT', 1, ',1,2,4,6,3,5,', 'includes/text.php', 'admin/includes/admin_text.php', 0, 1, 0, 0, 0, 0, 0, 0),
	(32, 'seitencontent in padding', 'Advertorial Seitencontent', 1, ',1,2,4,6,3,5,', 'includes/advertorial.php', 'admin/includes/admin_advertorial.php', 1, 0, 0, 0, 0, 0, 1, 0),
	(33, 'in padding', 'Suche', 1, ',1,2,4,6,3,5,', 'includes/tools/suche.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(34, 'in padding', 'BMI', 1, ',1,2,6,3,5,', 'includes/tools/bmi.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(35, 'in padding', 'Pulsfrequenz', 1, ',1,2,6,3,5,', 'includes/tools/pulsfrequenz.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(36, 'in padding', 'Newsletter', 1, ',1,2,4,6,3,5,', 'includes/tools/newsletter.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(37, 'in padding', 'Newsletter_abbestellen', 1, ',1,2,4,6,3,5,', 'includes/tools/newsletter_abbestellen.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(38, 'in padding', 'Gewinnspiel', 1, ',1,2,6,3,5,', 'includes/tools/gewinnspiel.php', '', 0, 0, 0, 0, 0, 1, 0, 1),
	(39, 'in padding', 'e-card', 1, ',1,2,6,3,5,', 'includes/tools/ecard.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(40, 'in padding', 'Sitemap', 1, ',1,2,4,6,3,5,', 'includes/tools/sitemap.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(41, 'in padding', 'Teaser', 1, ',1,2,6,3,5,', 'includes/teaser.php', 'admin/includes/admin_teaser.php', 0, 2, 0, 0, 0, 0, 0, 0),
	(42, 'seitencontent in padding', 'Übersichtsseite single no image', 0, ',1,2,6,3,5,', 'includes/uebersicht_single_no_img.php', 'admin/includes/admin_uebersicht_single_no_img.php', 0, 0, 0, 0, 0, 0, 1, 0),
	(43, 'sponsorbanner', 'Sponsorbanner', 1, ',1,2,4,6,3,5,', 'includes/advertorial.php', 'admin/includes/admin_advertorial.php', 1, 0, 0, 0, 0, 0, 1, 0),
	(44, 'in padding', 'Übersichtsseite auto dual image Subseiten', 0, ',1,2,6,3,5,', 'includes/uebersicht_auto_dual_img_subseiten.php', 'admin/includes/admin_uebersicht_auto_dual_img_subseiten.php', 0, 0, 0, 0, 0, 0, 0, 0),
	(45, 'in padding', 'Horoskop', 1, ',1,2,6,3,5,', 'includes/horoskop.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(46, 'in padding', 'Übersichtsseite auto dual image Rubrik', 0, ',1,2,6,3,5,', 'includes/uebersicht_auto_dual_img_rubrik.php', 'admin/includes/admin_uebersicht_auto_dual_img_rubrik.php', 0, 0, 0, 0, 0, 0, 0, 0),
	(47, 'seitencontent in padding', 'Seitencontent Teaser', 1, ',1,2,6,3,5,', 'includes/teaser.php', 'admin/includes/admin_teaser.php', 0, 2, 0, 0, 0, 0, 1, 0),
	(49, 'in padding', 'Image Teaser', 1, ',1,2,4,6,3,5,', 'includes/image_teaser.php', 'admin/includes/admin_image_teaser.php', 1, 5, 0, 1, 0, 0, 0, 0),
	(50, 'in padding', 'Fotowettbewerb', 1, ',1,2,6,3,5,', 'includes/fotowettbewerb.php', '', 0, 6, 0, 1, 0, 1, 0, 1),
	(51, 'in padding', 'Teaser neu', 1, ',1,2,4,6,3,5,', 'includes/teaser_mgt.php', 'admin/includes/admin_teaser_mgt.php', 0, 20, 0, 0, 0, 0, 0, 0),
	(52, 'in padding', 'Sibling Karussell', 1, ',1,2,4,6,3,5,', 'includes/sibling_browser.php', '', 0, 1, 0, 0, 0, 0, 0, 1),
	(53, 'seitencontent in padding', 'Login', 1, ',1,2,4,6,3,5,', 'includes/seitencontent/login.php', '', 0, 1, 0, 0, 0, 0, 0, 1),
	(54, 'seitencontent in padding', 'Seitenlayout Teaser neu', 1, ',1,2,4,6,3,5,', 'includes/teaser_mgt.php', 'admin/includes/admin_teaser_mgt.php', 0, 20, 0, 0, 0, 0, 0, 0),
	(55, 'seitencontent in padding', 'Blank TXT', 1, ',1,2,4,6,3,5,', 'includes/text.php', 'admin/includes/admin_text.php', 0, 1, 0, 0, 0, 0, 0, 0),
	(56, 'seitencontent in padding', 'Blank FCK', 1, ',1,2,4,6,3,5,', 'includes/text.php', 'admin/includes/admin_text.php', 0, 1, 0, 0, 0, 0, 0, 0),
	(57, 'seitencontent in padding', 'Seitencontent management bar', 1, ',1,4,3,5,', 'includes/seitencontent/management_bar.php', '', 0, 0, 0, 0, 0, 0, 0, 1),
	(58, 'in padding', 'Google adwords contentempfehlung f Artikel', 1, ',1,2,4,6,3,5,', 'includes/code.php', 'admin/includes/admin_code.php', 0, 0, 0, 0, 1, 0, 0, 0);
/*!40000 ALTER TABLE `element_layout` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
